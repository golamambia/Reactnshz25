import eng from './eng';
import ben from './ben';
import hin from './hin';

export default function getLabelLanguage(lang, key) {
  switch(lang) {
    case 'eng':
        return eng[key];
    case 'bn':
        return ben[key] ? ben[key] : eng[key];
    case 'hn':
        return hin[key] ? hin[key] : eng[key];
    default:
        return eng[key];
  }
}
