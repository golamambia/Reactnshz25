import {getService, getServiceAuthorized, postService, postServiceAuthorized, postServiceFormData, postServiceFormDataAuthorized} from '../configs/FetchRequest';

const RegistrationService = {};


// const loginPort = 9003;

RegistrationService.getStores = (payload) => postServiceFormData(
  `Masters/Stores`,
  payload,
);
 

RegistrationService.getInfluencers = (personaId, token) => getServiceAuthorized(
  `/api/v1/salesNode/sale/get/all/contractors/${personaId}`,
  token
)
RegistrationService.saveUser = (payload) => postServiceFormData(
  `User/CheckUser`,
  payload,
);
 

 

export default RegistrationService;
