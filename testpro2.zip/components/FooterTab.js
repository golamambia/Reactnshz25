import {
    Image,
    ImageBackground,
    Pressable,
    StyleSheet,
    Text,
    View,
    ScrollView,
    TouchableOpacity,
    SafeAreaView,
  } from 'react-native';
  import React, {useState, useEffect, useCallback} from 'react'
  
  import {
    HomeIcon,
    BellIcon,
    ExclamationCircleIcon,
    UserIcon,
    ArrowUpTrayIcon,
    PhotoIcon,
    GiftIcon,
    ShoppingCartIcon,
    DocumentTextIcon,
    ArrowDownTrayIcon,
    LockClosedIcon,
    QuestionMarkCircleIcon,
    LanguageIcon,
    DocumentMagnifyingGlassIcon,
    EnvelopeOpenIcon,
    PhoneArrowDownLeftIcon,
    StarIcon,
    ArrowRightOnRectangleIcon,
    MagnifyingGlassIcon,
  } from 'react-native-heroicons/outline';
  
  import ButtonGradient from '../components/ButtonGradient';
  import AsyncStorage from '@react-native-async-storage/async-storage';
  
  import { useFocusEffect, useNavigation } from '@react-navigation/native';
  import OtherService from '../services/Other';
  import Feather from 'react-native-vector-icons/Feather';
  import FontAwesome from 'react-native-vector-icons/FontAwesome';
  import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
  import {
    createBottomTabNavigator,
    BottomTabBar,
  } from '@react-navigation/bottom-tabs';
  import theme from '../constants/theme';

  
  const Tab = createBottomTabNavigator();
  const FooterTab =  ({ pageName = null }) => {
    const navigation = useNavigation();
      const [conId, setConId] = useState("");
       
      const [availablePoint, setAvailablePoint] = useState("");
    //const navigation = useNavigation();
  

    const navigateToScreen = (screenName) => {
      navigation.navigate(screenName);
    };
    const logoutHandler = navigation => {
      AsyncStorage.removeItem('my-key').then(res => {
        // dispatch(updateToken({token: ""}))
        console.log('my-key storage data', res);
        navigation.navigate('SignIn');
      });
  
      AsyncStorage.multiRemove([
        'contactId',
        'hierId',
        'user-name',
        'fullName',
        'brandId',
      ]).then(res => {
        console.log('Removed async storage data', res);
      });
    };
    return (
 
      <View
              style={{
               // flex:1,
                borderTopLeftRadius: 14,
        borderTopRightRadius: 14,
        backgroundColor: '#FFFFFF',
        //flexDirection: 'row',
        //alignItems: 'center',
        position: 'absolute',
        bottom: 40,
        left: 0,
        right: 0,
        //paddingVertical: 5,
        paddingHorizontal: 8,
   
    elevation: 50,
       
              }}
              
            >
           <View style={{justifyContent:'center',paddingTop:12,paddingBottom:12,flexDirection:'row'}} >
           <TouchableOpacity style={{flex:.5,position:'relative',alignItems:'center'}}
       className="flex-1 relative items-center "
        onPress={() => navigateToScreen('Dashboard')}>
              
                    {
                        pageName=='Home'?
                        (
                          
                          <Image  source={require("./../assets/Images/home_active.png")}  />
                         
                        ):(<Image source={require("./../assets/Images/home.png")} size={25}  />)
                      }
                      
                      <Text
                       className=" text-[#FFFFFF] text-[12px] font-ralebold"
                        style={styles.labelText}>
                        Home
                      </Text>
                      
                    

                    </TouchableOpacity>
                   
                    <TouchableOpacity
                    style={{flex:1,position:'relative',alignItems:'center'}}
      className="flex-1 items-center relative"
      onPress={() => navigation.navigate("SendBooking")}>
                   {
                        pageName=='SendBooking'?(<View>
                          <Image source={require("./../assets/Images/booking_active.png")} size={25}  />
                              </View> ):( <Image source={require("./../assets/Images/send_booking.png")} size={25}  />)
                      }
                   
                      <Text
                       className=" text-[#FFFFFF] text-[12px] font-ralebold"
                        style={styles.labelText}>
                       Send Booking
                      </Text>
                      
                      </TouchableOpacity>
                      <TouchableOpacity
                    style={{flex:1,position:'relative',alignItems:'center'}}
      className="flex-1 items-center relative"
      onPress={() => navigation.navigate("BookingStatus")}>
                   {
                        pageName=='BookingStatus'?(<Image source={require("./../assets/Images/booking_active.png")} size={25}  />):( <Image resizeMode='contain' source={require("./../assets/Images/send_booking.png")} size={25}  />)
                      }
                   
                      <Text
                       className=" text-[#FFFFFF] text-[12px] font-ralebold"
                        style={styles.labelText}>
                       Booking Status
                      </Text>
                      
                   
                    </TouchableOpacity>
                    
                    <TouchableOpacity
                    style={{flex:.5,position:'relative',alignItems:'center'}}
      className="flex-1 items-center relative"
      onPress={() => ''}>
                     
                     <Image resizeMode='contain' source={require("./../assets/Images/logout.png")} size={25}  />
                      <Text
                        className=" text-[#FFFFFF] text-[12px] font-ralebold"
                        style={styles.labelText}>
                       Logout
                      </Text>
                      
                    
                    </TouchableOpacity>
                   
          </View>
          </View>
    )     
    };
    export default FooterTab;
    
    const styles = StyleSheet.create({
      labelText:{fontSize:theme.fontSizes.small,
        fontWeight:theme.fontsWeight.regular,
        fontFamily:theme.fonts.regular,color:'#4A4A4A',
      lineHeight:15,
      paddingTop:4
      },
      container: {
        flex: 1,
      },
      pageParents: {
        backgroundColor: '#6759FF',
        flexDirection: 'row',
        alignItems: 'center',
      },
      box: {
        borderBottomWidth: 1,
        borderBottomColor: '#CFCFCF',
        paddingTop: 10,
        paddingBottom: 10,
      },
      boxText: {
        fontSize: 13,
        color: '#000000',
        fontWeight: 'normal',
        textAlign: 'left',
        marginLeft: 12,
      },
      log_box: {
        //borderBottomWidth: 1,
        //borderBottomColor: '#CFCFCF',
        paddingTop: 10,
        paddingBottom: 10,
      },
    });
    