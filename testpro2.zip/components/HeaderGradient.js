import { Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import LinearGradient from 'react-native-linear-gradient'
import theme from '../constants/theme';
import { useNavigation } from '@react-navigation/native';
import Feather from 'react-native-vector-icons/Feather';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

const HeaderGradient = ({headerText,
  icon = '',
  isOpen = false,
  setIsOpen = ()=>{},
  onPressIcon = ()=>{},
  pageName='',
  back = false,}) => {
    const splitText = headerText.split('/n');
    const navigation = useNavigation();
  function shortifyText(text){
    if(text){
      if(text.length > 30)
      return text.substring(0,30) + "...";
    return text;
  }
    }
    
  return (
    <View style={{flexDirection:'row',backgroundColor:'#518ADA',position:'relative',paddingVertical:splitText[1]?6:16}}>
        <View style={{flex: 1}}>
        
        {back && (
          <View style={{position:'absolute',left:11,paddingVertical:splitText[1]?12:0 }}>
        <Pressable className="ml-2" onPress={() => navigation.goBack()}>
              <MaterialIcons name={'arrow-back-ios-new'} size={20} color="white" />
            </Pressable>
            </View>
            )}
          <Text style={styles.text}>
            {shortifyText(splitText[0])}
          </Text>
          {splitText[1] &&
          <Text style={styles.subtext}>
            {shortifyText(splitText[1])}
          </Text>
  }
          {icon && (
            <View style={{position:'absolute',right:15,paddingVertical:10 }}>
            <Pressable onPress={() => {
              setIsOpen(true)
              onPressIcon()
              }}>
              <Feather name={icon} size={20} color="white" />
            </Pressable>
            </View>
          )}

          
        </View>
        
      </View>
                  
              
  )
}

export default HeaderGradient

const styles = StyleSheet.create({
  text: {
    color: '#FFFFFF',           
    textAlign: 'center',       
    fontFamily: theme.fonts.semiBold,           
    fontWeight: '600',       
    fontSize: 18,             
    lineHeight: 18,
    //paddingVertical:12 
    paddingTop:4          
  },
  subtext: {
    color: '#FFFFFF',           
    textAlign: 'center',       
    fontFamily: theme.fonts.semiBold,           
    fontWeight: '600',       
    fontSize: 18,             
    lineHeight: 22,
    paddingTop:4        
  },
})