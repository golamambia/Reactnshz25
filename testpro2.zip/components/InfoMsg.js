import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const InfoMsg = ({text}) => {
  return (
    <Text
      className="text-[14px] text-slate-500 text-center"
      style={{color: 'rgb(100 116 139)'}}>
      {text}
    </Text>
  );
};

export default InfoMsg;

const styles = StyleSheet.create({});
