import { StyleSheet, Text, View, Pressable, Dimensions } from 'react-native'
import React from 'react'
import { Shadow } from 'react-native-shadow-2'
import theme from '../constants/theme';
const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;
const ListItemTemplate = ({children,headingText='', onPress}) => {
    
 
  return (
    <View style={{marginTop:10,elevation:10}}>
            <Shadow
        distance={0}
        startColor={'#0000000A'}
        endColor={'#fff'}
        radius={8}
        offset={[0,0]}
        //sides={'bottom'}
        style={{ borderRadius: 8,width:'100%'}}
      >
       
        <View
          style={{
            //width:100,
            //height:80,
            padding:10,
            backgroundColor: '#fff',
            borderRadius: 8,
            //borderBottomRightRadius:20
           
          }}
        >
          {headingText &&
          <View>
          <Text style={styles.headerText}>
         {headingText}
            </Text>
          </View>
          }
          {children}
        </View>
      </Shadow>
     
    </View>
  )
}

export default ListItemTemplate

const styles = StyleSheet.create({
  headerText:{color:'#323030',fontSize:theme.fontSizes.fontSize18,fontWeight:theme.fontsWeight.bold,fontFamily:theme.fonts.bold,lineHeight:17,paddingTop:2,paddingBottom:6},

})