import React, {useState, useEffect, useRef} from 'react'
import {View, Text, StyleSheet, Pressable, Image, Modal, FlatList, TextInput} from "react-native"
import { XCircleIcon } from "react-native-heroicons/outline";
import ButtonRounded from './ButtonRounded';
import ButtonGradient from './ButtonGradient';

const OTPModal = ({openOTP, setOpenOTP, heading}) => {

    const [selected, setSelected] = useState("");
    const bgColor = (title) => {
      return selected == title?"bg-[#F3FFFF]" : "bg-white"
    }

    const pin1Ref = useRef(null);
    const pin2Ref = useRef(null);
    const pin3Ref = useRef(null);
    const pin4Ref = useRef(null);
    const pin5Ref = useRef(null);
    const pin6Ref = useRef(null);

    const [pin1, setPin1] = useState("")
    const [pin2, setPin2] = useState("")
    const [pin3, setPin3] = useState("")
    const [pin4, setPin4] = useState("");
    const [pin5, setPin5] = useState("")
    const [pin6, setPin6] = useState("");

    useEffect(() => {
        pin1Ref.current?.focus();
    },[])

    const resendOtpHandler = ()=>{
        console.log("resend OTP")
    }


  return (
    <View style={styles.centeredView} className="absolute">
        <Modal
        animationType="slide" 
        transparent={true}
        visible={openOTP}
        onRequestClose={() => {
        Alert.alert('Modal has been closed.');
        setOpenOTP(!openOTP);
        
        }}>
         <View style={{flex:1, backgroundColor:'rgba(0,0,0,0.65)'}}>
          <View className="" style={{
            // height: `${(modalOptions.length*11)+15}%`,
            height: `80%`,
            width: '98%',
            opacity:1,
            marginTop: 'auto',
            borderTopLeftRadius: 13,
            borderTopRightRadius:13,
            backgroundColor:'#fff',
            alignSelf: 'center',
            // backgroundColor:'blue'
          }}>
              <View className="pt-4 px-4">
                <View className="flex-row justify-between items-center">
                 
                  <View>
          <Text className="text-[#181D28] font-bold text-[24px] mb-[2px]">{heading}</Text>
          <Text className="text-[#738088] font-semibold text-[16px] ">Otp verification code send by to your 
Phone number ******4580</Text>
        </View>
                  <Pressable className="mt-[-35px]" onPress={()=>setOpenOTP((p) => !p)}><XCircleIcon color="#444" size={30} /></Pressable>
                </View>
                <View className="py-4">
<View className="items-center mb-[-10px]">
  <Image source={require("./../assets/Images/otp-lock.png")}  />
  </View>
                
                    <View style={{...stylesOTP.otpContainer}}>
                            <View style={stylesOTP.otpInputWrap}>
                                <TextInput
                                    ref={pin1Ref}
                                    keyboardType={'number-pad'}
                                    maxLength={1}
                                    onChangeText={(pin) => {
                                        setPin1(pin);
                                        if(pin !== ""){
                                            pin2Ref.current?.focus();
                                        }
                                    }}
                                    style={stylesOTP.textInputOtp}
                                    />
                            </View>
                            <View style={stylesOTP.otpInputWrap}>
                                <TextInput
                                    ref={pin2Ref}
                                    keyboardType={'number-pad'}
                                    maxLength={1}
                                    onChangeText={(pin) => {
                                        setPin2(pin);
                                        if(pin !== ""){
                                            pin3Ref.current?.focus();
                                        }
                                    }}
                                    style={stylesOTP.textInputOtp}
                                    />
                            </View>
                            <View style={stylesOTP.otpInputWrap}>
                                <TextInput 
                                    ref={pin3Ref}
                                    keyboardType={'number-pad'}
                                    maxLength={1}
                                    onChangeText={(pin) => {
                                        setPin3(pin);
                                        if(pin !== ""){
                                            pin4Ref.current?.focus();
                                        }
                                    }}
                                    style={stylesOTP.textInputOtp}
                                />
                            </View>
                            <View style={stylesOTP.otpInputWrap}>
                                <TextInput 
                                    ref={pin4Ref}
                                    keyboardType={'number-pad'}
                                    maxLength={1}
                                    onChangeText={(pin) => {
                                        setPin4(pin);
                                        if(pin !== ""){
                                            pin4Ref.current?.focus();
                                        }
                                    }}
                                    style={stylesOTP.textInputOtp}
                                />
                            </View>
                            <View style={stylesOTP.otpInputWrap}>
                                <TextInput 
                                    ref={pin5Ref}
                                    keyboardType={'number-pad'}
                                    maxLength={1}
                                    onChangeText={(pin) => {
                                        setPin5(pin);
                                        if(pin !== ""){
                                            pin5Ref.current?.focus();
                                        }
                                    }}
                                    style={stylesOTP.textInputOtp}
                                />
                            </View>
                            <View style={stylesOTP.otpInputWrap}>
                                <TextInput
                                    ref={pin6Ref}
                                    keyboardType={'number-pad'}
                                    maxLength={1}
                                    onChangeText={(pin) => {
                                        setPin6(pin);
                                    }}
                                    style={stylesOTP.textInputOtp}
                                />
                            </View>
                          

                    </View>
                    <View className="mt-12">
                        <ButtonGradient onPress={() => {}}>Submit</ButtonGradient>
                    </View>
                </View>


                <View className="flex-row pt-4   justify-center items-center">
            <Text className="text-center font-medium text-[#6F7074] text-[15px]">
            Your OTP Will Expire in 0:48
            </Text>
           
          </View>

                
              </View>
              <View className="mt-[130px] bottom-6 left-0 right-0">
              <View className="  flex-row  justify-center items-center ">
            <Text className="text-center font-semibold text-[#000000] text-[17px]">
            Not your employee code?</Text>
            <Pressable onPress={() => navigation.replace('SignIn')}>
              <Text className="text-[#FF1933] font-bold text-[17px]"> Change it</Text>
            </Pressable>
          </View>

              <View className="mt-[10px]  flex-row  justify-center items-center ">
            <Text className="text-center font-semibold text-[#000000] text-[17px]">
            Don’t get OTP?</Text>
            <Pressable onPress={() => navigation.replace('SignIn')}>
              <Text className="text-[#FF1933] font-bold text-[17px]"> Resend</Text>
            </Pressable>
          </View>


          </View>
             
          </View>
         



          
        </View> 
        
    </Modal>
  </View>
  )
}

const stylesOTP = StyleSheet.create({
    headingText: {
        fontFamily: 'Adani-Regular',
        fontSize: 30,
        fontWeight: 'bold',
        textAlign: 'center',
        color: '#1E1E1E'
      },
      fontFamily: {
        fontFamily: 'Adani-Regular'
      },
      otpContainer : {
        // flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        minHeight: 40
    },

    otpInputWrap: {
        width: 50,
        height: 50,
        borderWidth :2,
        borderColor: '#CECECE',
        justifyContent: "center",
        alignItems: 'center',
        marginHorizontal:4,
        marginTop: 30
    },

    textInputOtp: {
        fontSize: 30,
        color:"#292929",
        padding:0,
        margin:0
    }
    
})

const styles = StyleSheet.create({
    centeredView: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 22,
      backgroundColor:"#000"
    },
    modalView: {
      margin: 20,
      backgroundColor: 'white',
      borderRadius: 20,
      padding: 35,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 5,
    },
    button: {
      borderRadius: 20,
      padding: 10,
      elevation: 2,
    },
    buttonOpen: {
      backgroundColor: '#F194FF',
    },
    buttonClose: {
      backgroundColor: '#2196F3',
    },
    textStyle: {
      color: 'white',
      fontWeight: 'bold',
      textAlign: 'center',
    },
    modalText: {
      marginBottom: 15,
      textAlign: 'center',
    },
    fontFamily: {
        fontFamily: 'Adani-Regular'
      }
  });

export default OTPModal