import React from 'react'
import {Pressable, View, Text, TouchableOpacity, StyleSheet, Dimensions} from 'react-native';
import theme from '../constants/theme';
const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;
const ButtonNormal = ({children, onPress, disabled=false,bgColor}) => {

  const isDisabled = () => {
    return disabled?"bg-[#75b2f8]" : "bg-[#0D66CA]"
  }
  const isColor= () => {
    //console.log(bgColor);
    return bgColor?bgColor : "#0D66CA";
  }

  return (
    <TouchableOpacity style={styles.buttonWhite} disabled={disabled} onPress={onPress}>
        <Text style={styles.buttonText} >{children}</Text>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  buttonText: {
    fontFamily: 'Adani-Regular',
    color: theme.colors.white,
textAlign: 'center', 
fontWeight: '500',
fontFamily: theme.fonts.medium, 
fontSize: theme.fontSizes.medium, 
//letterSpacing: 1.25,
textTransform:'uppercase',
// lineHeight:19
},
buttonWhite:{
  width:'100%',
paddingVertical:screenHeight*0.012,
backgroundColor:theme.colors.primary,
borderColor:theme.colors.primary,
marginVertical:screenHeight*0.008,
borderRadius:5,
borderWidth:1
} 
})

export default ButtonNormal