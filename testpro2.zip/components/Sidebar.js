import {
  Image,
  ImageBackground,
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import React, {useState, useEffect, useCallback} from 'react'

import {
  HomeIcon,
  BellIcon,
  ExclamationCircleIcon,
  UserIcon,
  ArrowUpTrayIcon,
  PhotoIcon,
  GiftIcon,
  ShoppingCartIcon,
  DocumentTextIcon,
  ArrowDownTrayIcon,
  LockClosedIcon,
  QuestionMarkCircleIcon,
  LanguageIcon,
  DocumentMagnifyingGlassIcon,
  EnvelopeOpenIcon,
  PhoneArrowDownLeftIcon,
  StarIcon,
  ArrowRightOnRectangleIcon,
} from 'react-native-heroicons/outline';

import ButtonGradient from '../components/ButtonGradient';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { useFocusEffect, useNavigation } from '@react-navigation/native';
import OtherService from '../services/Other';
import Feather from 'react-native-vector-icons/Feather';
import { useDrawerStatus } from '@react-navigation/drawer';
import theme from '../constants/theme';
const screenHeight = Dimensions.get("screen").height;
const screenWidth = Dimensions.get("screen").width;
const Sidebar = props => {
  const drawerStatus = useDrawerStatus();
  const navigation = useNavigation();
 // console.log('drawerStatus',drawerStatus);
    const [conId, setConId] = useState("")
    const [hierId, setHierId] = useState("")
    const [hierName, setHiername] = useState("")
    
  //const navigation = useNavigation();

  const logoutHandler = navigation => {
    AsyncStorage.removeItem('my-key').then(res => {
      // dispatch(updateToken({token: ""}))
      console.log('my-key storage data', res);
      navigation.navigate('SignIn');
    });

    AsyncStorage.multiRemove([
      'contactId',
      'hierId',
      'user-name',
      'fullName',
      'brandId',
    ]).then(res => {
      console.log('Removed async storage data', res);
    });
  };

  useFocusEffect(
    React.useCallback(() => {
      
    }, [])
  );


  useEffect(() => {
    console.log('sidebar hit');
    
    AsyncStorage.getItem("contactId").then(conId=>{
      setConId(conId)
  })
  AsyncStorage.getItem("user-name").then(name=>{
      // console.log("NAMEEEE", name)
      //setUserName(name)
  })
  AsyncStorage.getItem("fullName").then(name=>{
      // console.log("NAMEEEE", name)
      //setFullName(name)
  })

 
 
 
},[drawerStatus]);

 const screenHandler=(srn)=>{
  navigation.navigate(srn);
 }
 
  return (
    <SafeAreaView style={styles.container}>
       
        <View
          style={styles.imageBox}>
           
           <Image
        style={styles.width100}
        //resizeMode='contain'
        source={require('./../assets/Images/sidebar.png')} />
         
        </View>
      
      <ScrollView>
        <View style={styles.outerBox} className="flex-1 pr-4 pl-4 mt-[8px] mb-[10px]">
          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              style={{flexDirection:'row'}}
              onPress={() => {
                screenHandler('Dashboard');
                
              }}>
              <View>
              <Feather name="home" size={20} color="white" />
                
              </View>
              <View>
                <Text style={styles.boxText}> Home</Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              style={{flexDirection:'row'}}
              onPress={() => {
                screenHandler('SendBooking');
              
              }}>
              <View>
              <Feather name="alert-circle" size={20} color="white" />
                 
              </View>
              <View>
                <Text style={styles.boxText}> Send Bookings</Text>
              </View>
            </TouchableOpacity>
          </View>

          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              style={{flexDirection:'row'}}
              onPress={() => {
                screenHandler('BookingStatus');
              
              }}
              >
              <View>
              <Feather name="user" size={20} color="white" />
              </View>
              <View>
                <Text style={styles.boxText}> Booking Status</Text>
              </View>
            </TouchableOpacity>
          </View>
       

           
         
       
          
          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              style={{flexDirection:'row'}}
              onPress={() => {
                props.navigation.navigate("MyProfile");
              }}>
              <View>
              <Feather name="lock" size={20} color="white" />
              </View>
              <View>
                <Text style={styles.boxText}>Change Password</Text>
              </View>
            </TouchableOpacity>
          </View>
          
          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              style={{flexDirection:'row'}}
              onPress={() => {
                props.navigation.navigate('TermsNCondition');
              }}>
              <View>
              <Feather name="file-text" size={20} color="white" />
              </View>
              <View>
                <Text style={styles.boxText}>Terms & Condition</Text>
              </View>
            </TouchableOpacity>
          </View>
        
          
         
        
       
          
          <View style={styles.log_box}>
            <TouchableOpacity
              className="flex-row"
              style={{flexDirection:'row'}}
              onPress={() =>logoutHandler(props.navigation)}>
              <View>
              <Feather name="log-out" size={20} color="white" />
              </View>
              <View>
                <Text style={styles.boxText}>Logout</Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* <View className="w-[92%] mx-4 my-6 shadow-lg shadow-slate-500 self-center">
            <ButtonGradient onPress={() => logoutHandler(props.navigation)}>
              Logout
            </ButtonGradient>
          </View> */}

        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
export default Sidebar;

const styles = StyleSheet.create({
  width100:{
    width:'100%',
    height:'100%',
    resizeMode:'stretch'
  },
  imageBox:{
    flex:1,
    //width: screenWidth*.845,//337,
    //height: screenHeight*.4,//294,
     backgroundColor:theme.colors.primary,
    marginBottom:8
  },
  outerBox:{flex:1,paddingHorizontal:16},
  container: {
    flex: 1,
    backgroundColor:theme.colors.primary,
  //marginBottom:20
  },
  pageParents: {
    backgroundColor: theme.colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
  },
  box: {
    borderBottomWidth: 1,
    borderBottomColor: '#F4F4F4',
    paddingTop: 8,
    paddingBottom: 8,
    flexDirection:'row'
  },
  boxText: {
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: theme.fontsWeight.medium,
    fontFamily:theme.fonts.medium,
    lineHeight:17,
    textAlign: 'left',
    marginLeft: 12,
  },
  log_box: {
    //borderBottomWidth: 1,
    //borderBottomColor: '#CFCFCF',
    paddingTop: 8,
    paddingBottom: 8,
    flexDirection:'row'
  },
});
