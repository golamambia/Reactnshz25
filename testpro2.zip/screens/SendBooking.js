import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  ScrollView,
  View,
  Text,
  StyleSheet,
  Image,
  Pressable,
  SafeAreaView,
  Dimensions,
  Modal,
  TouchableOpacity,
  Platform,
  Animated,
} from 'react-native';

import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import { ArrowRightIcon, CameraIcon, HomeIcon } from 'react-native-heroicons/outline';
import FooterTab from '../components/FooterTab';

import InsideFormBg from '../components/InsideFormBg';
import { useFocusEffect } from '@react-navigation/native';
import ListItemTemplate from '../components/ListItemTemplate';
import theme from '../constants/theme';
import ListItemRow from '../components/ListItemRow';
import ButtonNormal from '../components/ButtonNormal';
import PoweredByMJ from '../components/PoweredByMJ';
import FormPopup from '../components/FormPopup';
import ButtonWhite from '../components/ButtonWhite';
import InputField from '../components/InputField';
import OptionsInputField from '../components/OptionsInputField';
import CustomDatePicker from '../components/CustomDatePicker';
import { RadioButton } from 'react-native-paper';


const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;

const SendBooking = ({ navigation }) => {
  const [currentTab, setCurrentTab] = useState('Performance');
  const [visibleIds, setVisibleIds] = useState({});
  const animationValues = useRef({}).current;
  const [openModal, setOpenModal] = useState(false);
  const [truckNo, setTruckNo] = useState('');
  const [stateList,setStateList]=useState([]);
  const [check, setCheck] = useState(1);
  const [selectedState, setSelectedState] = useState('Jharkhand');
  const [bookingDate, setBookingDate] = useState('07/11/24');
  const [category, setCategory] = useState('NA');
  const [areaDefination, setAreaDefination] = useState('Out Station');
  const [capacity, setCapacity] = useState('');
  const [drivingLicence, setDrivingLicence] = useState('');
  const [pinNo, setPinNo] = useState('');
  const [pinNoc, setPinNoc] = useState('');
  const [loading, setLoading] = useState(false);
  const [filterRadio, setfilterRadio] = useState('');

  useFocusEffect(
    React.useCallback(() => {
        navigation.getParent('parentDrawer').setOptions({
            headerShown: true
        })
      })
    )

  const toggleRows = (id) => {
    const isVisible = !!visibleIds[id];
    setVisibleIds((prevState) => ({
      ...prevState,
      [id]: !isVisible,
    }))

  Animated.timing(animationValues[id], {
    toValue: isVisible ? 0 : 1,
    duration: 800, // Slow animation duration
    useNativeDriver: false,
  }).start();
};
  const templates = [
    {
      id: '1234567890',
      headingText: 'Booking ID - 1234567890',
      
    },

    
  ];
  templates.forEach((template) => {
    if (!animationValues[template.id]) {
      animationValues[template.id] = new Animated.Value(0);
    }
  });
  
  const tabHandler=(tab)=>{
    
console.log('tab ',tab);
  }
  return (
    <InsideFormBg paddingHorizontal={false} headerText="Send Booking /n सेंड बुकिंग " back={false}>
      
<View style={styles.tabWrapper}>
  <TouchableOpacity style={[styles.tabBox,styles.rightBorderWidth]}  onPress={()=>tabHandler('tailing')}>
<View style={styles.tabInnerBox}>
 
  <View style={{width:24,height:24}}>
    <Image style={styles.image100} source={require("./../assets/Images/icon/tailing_icon.png")} size={25}  />
    </View>
  <Text style={styles.labelText}>
  Tailing
  </Text>
</View>
  </TouchableOpacity>
  
  <TouchableOpacity style={[styles.tabBox,styles.rightBorderWidth]} onPress={()=>tabHandler('bokaro')}>
  <View style={styles.tabInnerBox}>
  <View style={{width:20,height:20}}>
    <Image style={styles.image100} source={require("./../assets/Images/icon/mappin_icon.png")}   />
    </View>
  
  <Text style={styles.labelText}>
  West Bokaro
  </Text>
</View>
  </TouchableOpacity>
  
  <TouchableOpacity style={styles.tabBox} onPress={()=>tabHandler('wbok')}>
  <View style={styles.tabInnerBox}>
    <View style={{width:24,height:24}}>
    <Image style={styles.image100} source={require("./../assets/Images/icon/mining_icon.png")} size={25}  />
    </View>
  
  <Text style={styles.labelText}>
  WBOK
  </Text>
</View>
  </TouchableOpacity>
</View>
<View style={{paddingHorizontal:theme.paddingHorizontal}}>
<ScrollView showsVerticalScrollIndicator={false}>

          <View style={styles.mainDiv}>
          {templates.map((template) => {
        const heightInterpolation = animationValues[template.id]?.interpolate({
          inputRange: [0, 1],
          outputRange: [0, 3 * 35], // Assuming each row is 50px tall
        });

        return (
          <ListItemTemplate
          key={template.id}
       // headingText={'Booking ID - 1234567890'}
        >
          
      
        <ListItemRow lefttext={'27C Availability(27C अवेलेबिलिटी )'} rightText={'Yes'} />
       
        <ListItemRow lefttext={'DO No(DO नंबर)'} rightText={'88889905112024'}  />
        <ListItemRow lefttext={'Balance Amount (INR)(बैलेंस अमाउंट )'} rightText={'₹99,43507.75'} />
       
        <ListItemRow lefttext={'Balance Quantity(MT) (बैलेंस क्वांटिटी )'} rightText={'1760.240'} />
        
     

        </ListItemTemplate>
 );
})}
<View style={{marginTop:8}}>

<ListItemTemplate headingText={'Please Fill the Following Form'}>
{/* <OptionsInputField
                    data={stateList}
                    fieldName="State"
                    value={selectedState}
                    setValue={setSelectedState}
                    required={true}
                    check={check}
                    modalHeading="Select State"
                    modalIcon={''}
                  /> */}
            <InputField fieldName="State" editable={false} required={true} value={selectedState} setValue={setSelectedState} check={check}  />
            <InputField fieldName="Category" editable={false} required={true} value={category} setValue={setCategory} check={check}  />
            <InputField fieldName="Area Definition" editable={false} required={true} value={areaDefination} setValue={setAreaDefination} check={check}  />
            
            <InputField fieldName="Truck No"  required={true} value={truckNo} setValue={setTruckNo} check={check}  />
            <InputField fieldName="Capacity (MT)"  required={true} value={capacity} setValue={setCapacity} check={check}  />
            <InputField fieldName="Driving Licence"  required={true} value={drivingLicence} setValue={setDrivingLicence} check={check}  />
            <InputField fieldName="Booking Date" editable={false} required={true} value={bookingDate} setValue={setBookingDate} check={check}  />
            <InputField fieldName="PIN"  required={true} value={pinNo} setValue={setPinNo} check={check}  />
            <InputField fieldName="Confirm PIN"  required={true} value={pinNoc} setValue={setPinNoc} check={check}  />
            
            <View>
              <Text style={styles.textLabel}>My truck has a reverse camera<Text style={{color: 'red'}}> *</Text></Text>
              <View style={{flexDirection:'row',}}>
            <View style={{flexDirection:'row',width:'25%'}}>
                                  <RadioButton
                                    uncheckedColor="#DFDFDF"
                                    value="yes"
                                    status={
                                      filterRadio === 'yes'
                                        ? 'checked'
                                        : 'unchecked'
                                    }
                                    onPress={() => setfilterRadio('yes')}
                                    color={theme.colors.primary}
                                  />
                                  <Text style={styles.radioTextLabel} >
                                  
                                    Yes

                                  </Text>
                                </View>
                                <View style={{flexDirection:'row',width:'25%'}}>
                                  <RadioButton
                                    uncheckedColor="#DFDFDF"
                                    value="no"
                                    status={
                                      filterRadio === 'no'
                                        ? 'checked'
                                        : 'unchecked'
                                    }
                                    onPress={() => setfilterRadio('no')}
                                    color={theme.colors.primary}
                                  />
                                  <Text style={styles.radioTextLabel} >
                                  
                                    No

                                  </Text>
                                </View>
                                </View>
                                {/* <Text style={styles.textRequiredMsg}>okoko</Text> */}
                                </View>

                                
            <View style={{marginTop:16,marginBottom:8}}>
              <ButtonNormal onPress={()=>{''}} loading={loading}>
              SEND Booking (सेंड बुकिंग)
              </ButtonNormal>
              </View>
        </ListItemTemplate>

<View style={{marginTop:28}}>
<PoweredByMJ backgroundColor={false} />
</View>

  
</View>
            </View>
            
    </ScrollView>
    
    </View>
      <FooterTab pageName="SendBooking" />
     

    </InsideFormBg>
  );
};

const styles = StyleSheet.create({
  textRequiredMsg: {
    position: 'absolute',
    color: theme.colors.error,
    bottom: -12,
    paddingLeft: 2,
    fontSize: theme.fontSizes.small,
    textTransform: 'capitalize',
  },
  warnImg: {height: 24, width: 24, position: 'absolute', right: 8, top: '45%'},
  textLabel: {
    paddingLeft: 2,
    color: theme.colors.inputLabelColor,
    fontSize: theme.fontSizes.fontSize14,
    fontWeight: theme.fontsWeight.medium,
    fontFamily: theme.fonts.medium,
  },
  radioTextLabel: {
    paddingTop:8,
    //paddingLeft: 2,
    color: theme.colors.inputLabelColor,
    fontSize: theme.fontSizes.fontSize14,
    fontWeight: theme.fontsWeight.medium,
    fontFamily: theme.fonts.medium,
  },
  textField: {
    paddingVertical: 8,
    paddingTop: 8,
    paddingHorizontal: 8,
    paddingLeft: 10,
    borderWidth: 1,
    borderColor: theme.colors.inputBoxBorderColor,
    borderRadius: 5,
    fontSize: theme.fontSizes.fontSize14,
    color: theme.colors.inputTextColor,
    fontWeight: theme.fontsWeight.regular,
    fontFamily: theme.fonts.regular,
  },
  tabWrapper:{flexDirection:'row',justifyContent:'center',alignItems:'center',alignContent:'center'},
  image100:{width:'100%',height:'100%'},
  rightBorderWidth:{borderRightWidth:2,borderRightColor:'#FFFFFF',},
  tabInnerBox:{flexDirection:'row',alignSelf:'center'},
  tabBox:{flex:1,backgroundColor:theme.colors.primary,borderTopColor:'#FFFFFF',borderTopWidth:2,
    justifyContent:'center',alignItems:'center',
    alignSelf:'center', paddingVertical:8,},
  labelText:{fontSize:theme.fontSizes.small,
    fontWeight:theme.fontsWeight.semiBold,
    fontFamily:theme.fonts.semiBold,color:'#FFFFFF',
  lineHeight:16,
  paddingVertical:4,
  paddingHorizontal:8
  },
  mainDiv:{marginTop:12,marginBottom:screenHeight*0.19},
  borderLine:{borderTopColor:'#DFDFDF',borderTopWidth:1,marginTop:8,paddingTop:8,flexDirection:'row',justifyContent:'space-between',paddingHorizontal:2,paddingBottom:4},
  textUnderLine:{fontSize:theme.fontSizes.fontSize14,fontWeight:theme.fontsWeight.semiBold,fontFamily:theme.fonts.semiBold,
    textAlign:'center',lineHeight:17,color:theme.colors.primary,textDecorationLine:'underline',
    textDecorationStyle:'solid',
  },
});

export default SendBooking;
