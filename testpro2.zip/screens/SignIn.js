import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Pressable,
  Dimensions,
  Alert,
} from 'react-native';
 

import FormBackground from '../components/FormBackground';

import {useFocusEffect} from '@react-navigation/native';

import AsyncStorage from '@react-native-async-storage/async-storage';
import {useDispatch} from 'react-redux';
import {useToast} from 'react-native-toast-notifications';
import ButtonNormal from '../components/ButtonNormal';
import ButtonWhite from '../components/ButtonWhite';
import theme from '../constants/theme';
import PoweredByMJ from '../components/PoweredByMJ';
import CoalengineImage from '../components/CoalengineImage';

const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;

const SignIn = ({route, navigation}) => {
  const toast = useToast();
  const dispatch = useDispatch();

  useEffect(() => {
    //console.log('signup hit');
    AsyncStorage.getItem('my-key').then(token => {
      console.log('token signup', token);
      if (token != null) {
        navigation.replace('Dashboard');
      }
    });

 
  }, []);

  useEffect(() => {
    const unsubscribe = navigation.addListener('beforeRemove', e => {
      console.log('event', e.data.action.type);
      if (e.data.action.type === 'REPLACE') {
        return;
      }
      e.preventDefault();
    });
    return unsubscribe;
  }, [navigation]);

  useFocusEffect(
    React.useCallback(() => {
      navigation.getParent('parentDrawer').setOptions({
        headerShown: false,
      });
      
    }, []),
  );

  
  const signInHandler = () => {
    //navigation.replace('PreSignIn');
    navigation.navigate('PreSignIn');
  }
  


  return (
   
      <FormBackground>

        <View style={styles.mainBox}>
        <CoalengineImage logo={true} />
         
        <View style={styles.textDiv}>
          <Text style={styles.textWelcome} >Welcome to IBMD</Text>
          <Text style={styles.textIndutry} >The Industrial By-product Management Division (IBMD) of Tata Steel handles a variety of by-products and scrap in the entire value chain of the steel company.</Text>
        </View>

                  

            <View >
              <ButtonNormal onPress={signInHandler}>
              Login (लॉगिन)
              </ButtonNormal>
              <View style={{marginTop:screenHeight*0.008,}}>
              <ButtonWhite onPress={()=>navigation.navigate('BookingStatus')} >
              Register (रजिस्टर) 
              </ButtonWhite>
              </View>
            </View>
             
          </View>
       
        <PoweredByMJ />
      </FormBackground>
    
  );
};

const styles = StyleSheet.create({

  textIndutry:{fontSize:theme.fontSizes.fontSize14,lineHeight:17,
    fontWeight:"400",fontFamily:theme.fonts.regular,textAlign:'center',color:'#595858',marginTop:15},
  textWelcome:{fontSize:theme.fontSizes.fontSize22,lineHeight:26,
    fontWeight:'700',fontFamily:theme.fonts.bold,textAlign:'center',color:'#323030'},
  textDiv:{
    marginTop:screenHeight*0.015,
    marginBottom:screenHeight*0.03},
  mainBox:{
    flex:1
   // minHeight: 807.27 * 0.8, 
   // height: screenHeight * 0.7,
    //marginTop:screenWidth * 0.025,
    //justifyContent:'space-between'
  },
   
 
});

export default SignIn;
