import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  ScrollView,
  View,
  Text,
  StyleSheet,
  Image,
  Pressable,
  SafeAreaView,
  Dimensions,
  Modal,
  TouchableOpacity,
  Platform,
  Animated,
} from 'react-native';

import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import { ArrowRightIcon, CameraIcon, HomeIcon } from 'react-native-heroicons/outline';
import FooterTab from '../components/FooterTab';

import InsideFormBg from '../components/InsideFormBg';
import { useFocusEffect } from '@react-navigation/native';
import ListItemTemplate from '../components/ListItemTemplate';
import theme from '../constants/theme';
import ListItemRow from '../components/ListItemRow';
import ButtonNormal from '../components/ButtonNormal';
import PoweredByMJ from '../components/PoweredByMJ';
import FormPopup from '../components/FormPopup';
import ButtonWhite from '../components/ButtonWhite';
import InputField from '../components/InputField';



const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;

const BookingStatus = ({ navigation }) => {
  const [currentTab, setCurrentTab] = useState('Performance');
  const [visibleIds, setVisibleIds] = useState({});
  const animationValues = useRef({}).current;
  const [openModal, setOpenModal] = useState(false);
  const [pinNo, setPinNo] = useState('');
  const [pinNoc, setPinNoc] = useState('');
  const [check, setCheck] = useState(1);

  useFocusEffect(
    React.useCallback(() => {
        navigation.getParent('parentDrawer').setOptions({
            headerShown: true
        })
      })
    )

  const toggleRows = (id) => {
    const isVisible = !!visibleIds[id];
    setVisibleIds((prevState) => ({
      ...prevState,
      [id]: !isVisible,
    }))

  Animated.timing(animationValues[id], {
    toValue: isVisible ? 0 : 1,
    duration: 800, // Slow animation duration
    useNativeDriver: false,
  }).start();
};
  const templates = [
    {
      id: '1234567890',
      headingText: 'Booking ID - 1234567890',
      
    },
    {
      id: '0987654321',
      headingText: 'Booking ID - 0987654321',
      
    },
    {
      id: '09876543211',
      headingText: 'Booking ID - 0987654321',
      
    },
    {
      id: '09876543212',
      headingText: 'Booking ID - 0987654321',
      
    },
    {
      id: '09876543213',
      headingText: 'Booking ID - 0987654321',
      
    },
  ];
  templates.forEach((template) => {
    if (!animationValues[template.id]) {
      animationValues[template.id] = new Animated.Value(0);
    }
  });
  
  const tabHandler=(tab)=>{
    
console.log('tab ',tab);
  }
  return (
    <InsideFormBg paddingHorizontal={false} headerText="Booking Status /nबुकिंग स्टेटस " back={false}>
      
<View style={styles.tabWrapper}>
  <TouchableOpacity style={[styles.tabBox,styles.rightBorderWidth]}  onPress={()=>tabHandler('tailing')}>
<View style={styles.tabInnerBox}>
 
  <View style={{width:24,height:24}}>
    <Image style={styles.image100} source={require("./../assets/Images/icon/tailing_icon.png")} size={25}  />
    </View>
  <Text style={styles.labelText}>
  Tailing
  </Text>
</View>
  </TouchableOpacity>
  
  <TouchableOpacity style={[styles.tabBox,styles.rightBorderWidth]} onPress={()=>tabHandler('bokaro')}>
  <View style={styles.tabInnerBox}>
  <View style={{width:20,height:20}}>
    <Image style={styles.image100} source={require("./../assets/Images/icon/mappin_icon.png")}   />
    </View>
  
  <Text style={styles.labelText}>
  West Bokaro
  </Text>
</View>
  </TouchableOpacity>
  
  <TouchableOpacity style={styles.tabBox} onPress={()=>tabHandler('wbok')}>
  <View style={styles.tabInnerBox}>
    <View style={{width:24,height:24}}>
    <Image style={styles.image100} source={require("./../assets/Images/icon/mining_icon.png")} size={25}  />
    </View>
  
  <Text style={styles.labelText}>
  WBOK
  </Text>
</View>
  </TouchableOpacity>
</View>
<View style={{paddingHorizontal:theme.paddingHorizontal}}>
<ScrollView showsVerticalScrollIndicator={false}>

          <View style={styles.mainDiv}>
          {templates.map((template) => {
        const heightInterpolation = animationValues[template.id]?.interpolate({
          inputRange: [0, 1],
          outputRange: [0, 3 * 35], // Assuming each row is 50px tall
        });

        return (
          <ListItemTemplate
          key={template.id}
        headingText={'Booking ID - 1234567890'}
        >
          
      
        <ListItemRow lefttext={'Booking Date'} rightText={' 06/11/24'} />
       
        <ListItemRow lefttext={'Booking Status'} rightText={'Approved'} status={'Approved'} />
        
        <Animated.View
              style={{
                height: heightInterpolation,
                overflow: 'hidden',
              }}
            >
      <ListItemRow lefttext={'Truck No.'} rightText={'WB1111'} />
       <ListItemRow lefttext={'Capacity(MT)'} rightText={'10'} />
       <ListItemRow lefttext={'Driving Licence'} rightText={'LI1111'} />
       <ListItemRow lefttext={'Booking Pin No.'} rightText={'1234'} />
       <ListItemRow lefttext={'Booking Confirmation No.'} rightText={'606553'} />
       </Animated.View>


       <View style={styles.borderLine}>
                   <View><TouchableOpacity onPress={()=>''}>
                   <Text style={styles.textUnderLine}>Resend SMS</Text>
                       </TouchableOpacity></View>
                       <View><TouchableOpacity onPress={()=>setOpenModal(true)}>
                       <Text style={styles.textUnderLine}>Edit Pin</Text>
                       </TouchableOpacity></View>
                     </View>
                     <View >
                     <ButtonNormal onPress={() => toggleRows(template.id)}>
              {visibleIds[template.id] ? 'View Less' : 'View More'}
            </ButtonNormal>
              </View>

        </ListItemTemplate>
 );
})}
<View style={{marginTop:24}}>

<PoweredByMJ backgroundColor={false} />
  
</View>
            </View>
            
    </ScrollView>
    
    </View>
      <FooterTab pageName="BookingStatus" />
      {openModal && (
        <FormPopup
          open={openModal}
          setOpen={setOpenModal}
          heading={'Edit pin Number'}
          transparent={true}>
<View>
<InputField fieldName="PIN No."  required={true} value={pinNo} setValue={setPinNo} check={check}  />
<InputField fieldName="Confirm PIN"  required={true} value={pinNoc} setValue={setPinNoc} check={check}  />

<View style={{flexDirection:'row',justifyContent:'space-between'}}>
              <View style={{width:'45%'}}>
                <ButtonWhite onPress={() => setOpenModal(false)}>
                Cancel
                </ButtonWhite>
              </View>
              <View style={{width:'45%'}}>
                <ButtonNormal onPress={() => setOpenModal(false)}>
                Update
                </ButtonNormal>
              </View>
            </View>
          </View>
          </FormPopup>)}

    </InsideFormBg>
  );
};

const styles = StyleSheet.create({
  tabWrapper:{flexDirection:'row',justifyContent:'center',alignItems:'center',alignContent:'center'},
  image100:{width:'100%',height:'100%'},
  rightBorderWidth:{borderRightWidth:2,borderRightColor:'#FFFFFF',},
  tabInnerBox:{flexDirection:'row',alignSelf:'center'},
  tabBox:{flex:1,backgroundColor:theme.colors.primary,borderTopColor:'#FFFFFF',borderTopWidth:2,
    justifyContent:'center',alignItems:'center',
    alignSelf:'center', paddingVertical:8,},
  labelText:{fontSize:theme.fontSizes.small,
    fontWeight:theme.fontsWeight.semiBold,
    fontFamily:theme.fonts.semiBold,color:'#FFFFFF',
  lineHeight:16,
  paddingVertical:4,
  paddingHorizontal:8
  },
  mainDiv:{marginTop:12,marginBottom:screenHeight*0.19},
  borderLine:{borderTopColor:'#DFDFDF',borderTopWidth:1,marginTop:8,paddingTop:8,flexDirection:'row',justifyContent:'space-between',paddingHorizontal:2,paddingBottom:4},
  textUnderLine:{fontSize:theme.fontSizes.fontSize14,fontWeight:theme.fontsWeight.semiBold,fontFamily:theme.fonts.semiBold,
    textAlign:'center',lineHeight:17,color:theme.colors.primary,textDecorationLine:'underline',
    textDecorationStyle:'solid',
  },
});

export default BookingStatus;
