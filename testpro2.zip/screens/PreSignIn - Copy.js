import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Pressable,
  Dimensions,
  Alert,
} from 'react-native';
 
import InputField from '../components/InputField';
import RegistrationService from '../services/registration';
import {useSelector} from 'react-redux';
import FormBackground from '../components/FormBackground';
import ButtonGradient from '../components/ButtonGradient';

import {useFocusEffect} from '@react-navigation/native';

import AsyncStorage from '@react-native-async-storage/async-storage';
import {useDispatch} from 'react-redux';
import {
  addBrandId,
  addContactId,
  addCreatedById,
  addHierarchicalId,
  addOrganizationId,
  updateLoginStatus,
  updateToken,
} from '../store/redux/currentUser';

import {useToast} from 'react-native-toast-notifications';


const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;
console.log('sh', screenHeight);

const PreSignIn = ({route, navigation}) => {
  const toast = useToast();
  const dispatch = useDispatch();
   
  const [check, setCheck] = useState(1);

  const [selectedPersona, setSelectedPersona] = useState({id: '', title: ''});
  const [sap, setSap] = useState('');
  const [mob, setMob] = useState('');
  const [password, setPassword] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState({id: '', title: ''});
  const [allLanguages, setAllLanguages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [phase1Filled, setPhase1Filled] = useState(false);
  const [passCheck, setPassCheck] = useState(1);
  const [signInUsingOtp, setSignInUsingOtp] = useState(true);
  const [personas, setPersonas] = useState([]);
  const [fullName, setFullName] = useState('');
  

  useEffect(() => {
    //console.log('signup hit');
    AsyncStorage.getItem('my-key').then(token => {
      console.log('token signup', token);
      if (token != null) {
        navigation.replace('Dashboard');
      }
    });

 
  }, []);

  useEffect(() => {
    const unsubscribe = navigation.addListener('beforeRemove', e => {
      console.log('event', e.data.action.type);
      if (e.data.action.type === 'REPLACE') {
        return;
      }
      e.preventDefault();
    });
    return unsubscribe;
  }, [navigation]);

  useFocusEffect(
    React.useCallback(() => {
      navigation.getParent('parentDrawer').setOptions({
        headerShown: false,
      });
      
    }, []),
  );

  const storeData = async (
    accessToken,
    refreshToken,
    conId,
    hierId,
    username,
    brandId,
    fullName,
    hierCode,
    hierDesc,
    id_extern01,
  ) => {
    try {
      await AsyncStorage.setItem('my-key', accessToken);
      await AsyncStorage.setItem('my-refresh-key', refreshToken);
      await AsyncStorage.setItem('contactId', conId + '');
      await AsyncStorage.setItem('hierId', hierId + '');
      await AsyncStorage.setItem('user-name', username + '');
      await AsyncStorage.setItem('brandId', brandId + '');
      await AsyncStorage.setItem('fullName', fullName + '');
      await AsyncStorage.setItem('hierCode', hierCode + '');
      await AsyncStorage.setItem('hierDesc', hierDesc + '');
      await AsyncStorage.setItem('id_extern01', id_extern01 + '');
    } catch (e) {
      // saving error
    }
  };

  function resetFields() {
    setCheck(1);
    setPassCheck(1);
    setPhase1Filled(false);
    setSap('');
    setPassword('');
    setSelectedPersona({id: '', title: ''});
    setSelectedLanguage({id: '', title: ''});
    setMob('');
  }

  const signInHandler = () => {
    setCheck(p => p + 1);
    if (!selectedPersona.title || !(checkForDealerRetailer() ? sap : mob)) {
    } else {
      if (!phase1Filled) {
        setPhase1Filled(true);
      } else {
        //  sign in via password
        if (!signInUsingOtp) {
          setPassCheck(p => p + 1);
          if (
            !(checkForDealerRetailer() ? sap : mob) ||
            !password ||
            !selectedPersona.title
          ) {
            // intentionally kept blank
          } else {
            setLoading(true);
            const payload = {
              username: checkForDealerRetailer() ? sap : mob,
              password: password,
              userType: selectedPersona.id,
            };
            // console.log("selectedPersona", selectedPersona)
            // console.log(payload)
            RegistrationService.login(payload)
              .then(res => {
                console.log('login res', JSON.stringify(res));

                if (res.success) {
                  setLoading(false);
                  dispatch(updateLoginStatus({isLoggedIn: true}))
                  console.log("b---------", res.response.userData.dcm_brands_id)
                  dispatch(
                    addHierarchicalId({
                      hierId: res.response.userData.dcm_hierarchies_id,
                    }),
                  );
                  dispatch(
                    addContactId({
                      contId: res.response.userData.dcm_contacts_id,
                    }),
                  );
                  dispatch(
                    addOrganizationId({
                      orgId: res.response.userData.dcm_organization_id,
                    }),
                  );
                  dispatch(
                    addBrandId({
                      brandId: res.response.userData.dcm_brands_id,
                    }),
                  );
                  storeData(
                    res.response.access_token,
                    res.response.refresh_token,
                    res.response.userData.dcm_contacts_id,
                    res.response.userData.dcm_hierarchies_id,
                    res.response.userData.username,
                    res.response.userData.dcm_brands_id,
                    res.response.userData.full_name,
                    res.response.userData.hierCode,
                    res.response.userData.description,
                    res.response.userData.id_extern01,
                  );
                  console.log("reading toast")
                  toast.show('', {
                    data: {
                      isSuccess: true,
                      heading: 'Login Successful',
                      describe:
                        'You have successfully logged into RewardsConnect',
                    },
                  });

                  setTimeout(() => {
                    navigation.replace('Dashboard');
                  }, 1500);
                } else {
                  setLoading(false);
                  if (res.message == 'Bad request') {
                    toast.show('', {
                        data: {
                            isSuccess: false,
                            heading: 'Login failed!',
                            describe: res.response.message,
                          },
                      });
                  } else {
                    toast.show('', {
                        data: {
                            isSuccess: false,
                            heading: 'Login failed!',
                            describe: res.message,
                          },
                      });
                   
                  }
                }
              })
              .catch(err => {
                setLoading(false);
              });
          }
        } else {
          // sign in via otp login
        }
      }
    }
  };

  const moveToSignUp = () => {
    navigation.navigate('SignUp', {from: 'signin'});
    resetFields();
  };

  function checkForDealerRetailer() {
    if (
      selectedPersona.title == 'Retailer' ||
      selectedPersona.title == 'Dealer'
    ) {
      return true;
    }
    return false;
  }

  return (
   
      <FormBackground>

        <View
          className="flex-1 w-full bg-white  m-4 mt-[3px] p-4 shadow"
          style={{minHeight: 807.27 * 0.8, height: screenHeight * 0.7}}>
          <View className=" flex-1">
           
        <View>
          <Text className="text-[#181D28] font-bold text-[24px] mb-[2px]">Welcome 2!</Text>
          <Text className="text-[#738088] font-semibold text-[16px] ">Let’s get started with a free account</Text>
        </View>

                  <View className="flex flex-col space-y-5 justify-start items-start w-full mt-[40px]">
                 
                 <View className="w-full">
                   <InputField
                     fieldName="Registered Employee Code"
                     required={true}
                     value={fullName}
                     setValue={setFullName}
                     check={check}
                   />
                 </View>
                 </View>

            <View className="w-full pt-10">
              <ButtonGradient onPress={signInHandler} loading={loading}>
                {signInUsingOtp ? 'Get OTP' : 'Sign In'}
              </ButtonGradient>
            </View>

             
          </View>
          <View className="flex-row pt-2   justify-center items-center">
            <Text className="text-center font-semibold text-[#000000] text-[17px]">
            Don't have an account?
            </Text>
            <Pressable onPress={moveToSignUp}>
              <Text className="text-[#FF1933] font-bold text-[17px]"> Sign up</Text>
            </Pressable>
          </View>
        </View>
      </FormBackground>
    
  );
};

const styles = StyleSheet.create({
  headingText: {
    fontFamily: 'Adani-Regular',
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#1E1E1E',
  },
  fontFamily: {
    fontFamily: 'Adani-Regular',
    color: '#111',
    letterSpacing: 0.3,
    fontSize: 16,
  },
  adaniBold: {
    fontFamily: 'Adani-Bold',
  },
  logo: {
    width: screenWidth * 0.4,
    height: screenHeight * 0.06,
  },
});

export default PreSignIn;
