import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Pressable,
  Alert,
} from 'react-native';
 
  
import InputField from '../components/InputField';
 
import RegistrationService from '../services/registration';
 
import {useSelector} from 'react-redux';
import FormBackground from '../components/FormBackground';
import ButtonGradient from '../components/ButtonGradient';
import VerifyInputField from '../components/VerifyInputField';
 
 
import OTPModal from '../components/OTPModal';
 
 
 
import RewardsConnectFullLogo from '../components/RewardsConnectFullLogo';
import ProfileService from '../services/Profile';
import { useToast } from 'react-native-toast-notifications';
import OptionsInputField from '../components/OptionsInputField';
import CustomDatePicker from '../components/CustomDatePicker';
import LoadingAlert from '../components/LoadingAlert';
 

const SignUpINIT = ({route, navigation}) => {
  const toast = useToast();
  const {from} = route.params;
 

  const [toggleCheckBox, setToggleCheckBox] = useState(false);

  const [empCode, setempCode] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [openOTP, setOpenOTP] = useState(false);
  const [loading, setLoading] = useState(false);
  const [allFieldsFilled, setAllFieldsFilled] = useState(false);
  const [messageImage, setMessageImage] = useState("");
  const [check, setCheck] = useState(1);
  const [storName, setstorName] = useState({id: '', title: ''});
  const [storList, setstorList] = useState([]);
  const [showLoading, setShowLoading] = useState(false);
  const [DateofJoin, setDateofJoin] = useState('');

  useEffect(() => {
    getStoreList();
  }, []);

  
  

  function resetFields() {
    setCheck(1);
    setempCode('');
    setMobile('');
    setEmail('');
    
  }

   

  function ValidatePhoneNumber(num) {
    let contactPetrn = new RegExp(/^(\+\d{1,3}[- ]?)?\d{10}$/);
    let numS = num+""
    console.log(parseInt(numS.charAt(0)))
    if (contactPetrn.test(num) && parseInt(numS.charAt(0))>5) {
      return true;
    }
    return false;
  }

  function ValidateEmail(email) {
    let emailPetrn = new RegExp(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g);
    if (!emailPetrn.test(email)) {
      console.log('emailid false');
      return false;
    }
    console.log('emailid true');
    return true;
  }

  

  function submitHandler() {
   // setLoading(true);
  // setOpenOTP(true);
  if(!storName.id){
    Alert.alert(  
      '',  
      'Please select store name',  
      [  
           
          {text: 'OK', onPress: () =>''},  
      ]  
  );
  }else if(!empCode){
    Alert.alert(  
      '',  
      'Please enter employee code',  
      [  
           
          {text: 'OK', onPress: () =>''},  
      ]  
  );
  }else if(!DateofJoin){
    Alert.alert(  
      '',  
      'Please select date',  
      [  
           
          {text: 'OK', onPress: () =>''},  
      ]  
  );
  }else if(!mobile){
    Alert.alert(  
      '',  
      'Please enter mobile no',  
      [  
           
          {text: 'OK', onPress: () =>''},  
      ]  
  );
  }else{
    setShowLoading(true);
    console.log('DateofJoin',DateofJoin);
    const formData = new FormData();
    formData.append('Stotrname', storName.title);
    formData.append('StoreCode',storName.id);
    formData.append('EmpCode', empCode);
    formData.append('DateofJoin',DateofJoin);
    formData.append('Mobile', mobile);
    console.log('formData',formData);
    RegistrationService.saveUser(formData)
                .then(res => {
                  console.log('getStores res', res);
                  setShowLoading(false);
                  
                }).catch(err=>{
  
                })
  }

  }

  const verifyOtp = () => {
    setOpenOTP(true);
  };
  
  

  function onlyAlphabetHandler(text){
    const alphaRegex = new RegExp(/^[a-zA-Z ]*$/)
    if(alphaRegex.test(text)){
      setempCode(text)
    }
  }

  
const getStoreList=()=>{
  const formData = new FormData();
  //formData.append('file_type', " ");
  RegistrationService.getStores('')
              .then(res => {
               // console.log('getStores res', res);
                const get_data = res.map(item => {
                  return {
                    id: item.StoreCode,
                    title: item.Name,
                     
                  };
                });
                 setstorList(get_data);
              }).catch(err=>{

              })
}

  return (
    <ScrollView className="relative">
      <FormBackground >
        <View className="flex-1 w-full bg-white m-4  mt-[3px] p-4 shadow">
          <View className="flex-1">
          <View>
          <Text className="text-[#181D28] font-bold text-[24px] mb-[2px]">Welcome!</Text>
          <Text className="text-[#738088] font-semibold text-[16px] ">Let’s get started with a free account</Text>
        </View>
            
        <View className="flex flex-col space-y-5 justify-start items-start w-full mt-[40px]">
                 
        <View className="w-full">
                  <OptionsInputField
                    data={storList}
                    fieldName="Store Name"
                    value={storName}
                    setValue={setstorName}
                    required={true}
                    
                    modalHeading="Select your Store"
                    modalIcon={''}
                  />
                </View>

                <View className="w-full">
                  <InputField
                    fieldName="Store Code"
                    required={true}
                    value={storName.id}
                    setValue={onlyAlphabetHandler}
                    editable={false}
                  />
                </View>
                <View className="w-full">
                  <InputField
                    fieldName="Employee Code"
                    required={true}
                    value={empCode}
                    setValue={onlyAlphabetHandler}
                     
                  />
                </View>
                 
                <View className="w-full">
              <CustomDatePicker
                isDob={true}
                fieldText="Date of Joining"
                value={DateofJoin}
                setValue={setDateofJoin}
                required={true}
                //check={check}
                 
              />
            </View>
                <View className="w-full">
                  <InputField
                    fieldName="Mobile Number"
                    required={true}
                    value={mobile}
                    setValue={setMobile}
                     
                  />
                </View>
                
                
                
              </View>
           
          
            
            
              <View className="w-full pt-10">
                <ButtonGradient loading={loading} onPress={submitHandler}>
                  Get OTP
                </ButtonGradient>
              </View>
        
          </View>
          
          <View className="flex-row pt-2   justify-center items-center">
            <Text className="text-center font-semibold text-[#000000] text-[17px]">
            Already have an account?
            </Text>
            <Pressable onPress={() => navigation.replace('SignIn')}>
              <Text className="text-[#FF1933] font-bold text-[17px]"> Login</Text>
            </Pressable>
          </View>
          <OTPModal
            className="absolute"
            setOpenOTP={setOpenOTP}
            openOTP={openOTP}
            heading="OTP Verification"
          /> 
         
          
        </View>
        <LoadingAlert visible={showLoading} />
      </FormBackground>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  headingText: {
    fontFamily: 'Adani-Regular',
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#1E1E1E',
  },
  fontFamily: {
    fontFamily: 'Adani-Regular',
    color: '#111',
    letterSpacing: 0.3,
    fontSize: 16,
  },
  adaniBold: {
    fontFamily: 'Adani-Bold',
  },
});

export default SignUpINIT;
