import React, { useState, useEffect, useCallback } from 'react';
import {
  ScrollView,
  View,
  Text,
  StyleSheet,
  Image,
  Pressable,
  SafeAreaView,
  Dimensions,
  Modal,
  TouchableOpacity,
  Platform,
} from 'react-native';

import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import { ArrowRightIcon, CameraIcon, HomeIcon } from 'react-native-heroicons/outline';
import FooterTab from '../components/FooterTab';

import InsideFormBg from '../components/InsideFormBg';
import { useFocusEffect } from '@react-navigation/native';
import ListItemTemplate from '../components/ListItemTemplate';
import theme from '../constants/theme';



const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;

const Dashboard = ({ navigation }) => {
  const [currentTab, setCurrentTab] = useState('Performance');
  const [currentFilterTab, setcurrentFilterTab] = useState('MTD');
  const [modalSt, setModalSt] = useState(false);
  const [modalStd, setModalStd] = useState(false);
  useFocusEffect(
    React.useCallback(() => {
        navigation.getParent('parentDrawer').setOptions({
            headerShown: true
        })
      })
    )
  return (
    <InsideFormBg headerText="Booking Status">

<ScrollView>

          <View className="flex-1 ">
          <ListItemTemplate
        //key={item.sale_id}
        
        >
          <View>
          <Text style={{color:'#323030',fontSize:theme.fontSizes.fontSize18,fontWeight:theme.fontsWeight.bold,fontFamily:theme.fonts.bold,lineHeight:17,paddingTop:2,paddingBottom:6}} className="text-black font-medium text-[14px] tracking-wider">
          Booking ID - 1234567890
            </Text>
          </View>
        <View style={{flexDirection:'row',}}>
          <View style={{width:'50%'}}>
            <Text style={{color:'#595858',fontSize:theme.fontSizes.fontSize14,fontWeight:theme.fontsWeight.medium,fontFamily:theme.fonts.medium,}} className="text-black font-medium text-[14px] tracking-wider">
              {/* {getLabelLanguage(selLang, 'transaction_id')} */}
              Booking Date
            </Text>
          </View>
          <View style={{width:'50%'}}>
            <Text style={{textAlign:'right',color:'#707274',fontSize:theme.fontSizes.fontSize14,fontWeight:theme.fontsWeight.regular,fontFamily:theme.fonts.regular}} >
            06/11/24
            </Text>
          </View>
        </View>
        <View style={{flexDirection:'row',}}>
          <View style={{width:'50%'}}>
            <Text style={{color:'#595858',fontSize:theme.fontSizes.fontSize14,fontWeight:theme.fontsWeight.medium,fontFamily:theme.fonts.medium,}} className="text-black font-medium text-[14px] tracking-wider">
              {/* {getLabelLanguage(selLang, 'transaction_id')} */}
              Booking Date
            </Text>
          </View>
          <View style={{width:'50%'}}>
            <Text style={{textAlign:'right',color:'#707274',fontSize:theme.fontSizes.fontSize14,fontWeight:theme.fontsWeight.regular,fontFamily:theme.fonts.regular}} >
            06/11/24
            </Text>
          </View>
        </View>
        </ListItemTemplate>

            </View>
            
    </ScrollView>
      
      {/* <FooterTab pageName="Home" /> */}
    </InsideFormBg>
  );
};

const styles = StyleSheet.create({
  
});

export default Dashboard;
