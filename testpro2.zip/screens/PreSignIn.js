import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Pressable,
  Dimensions,
  Alert,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  BackHandler,
} from 'react-native';
 
import InputField from '../components/InputField';
import RegistrationService from '../services/registration';
import {useSelector} from 'react-redux';
import FormBackground from '../components/FormBackground';

import {useFocusEffect} from '@react-navigation/native';

import AsyncStorage from '@react-native-async-storage/async-storage';
import {useDispatch} from 'react-redux';
import {
  addBrandId,
  addContactId,
  addCreatedById,
  addHierarchicalId,
  addOrganizationId,
  updateLoginStatus,
  updateToken,
} from '../store/redux/currentUser';

import {useToast} from 'react-native-toast-notifications';
import ButtonNormal from '../components/ButtonNormal';
import ButtonWhite from '../components/ButtonWhite';
import theme from '../constants/theme';
import OptionsInputField from '../components/OptionsInputField';
import CustomDatePicker from '../components/CustomDatePicker';
import PoweredByMJ from '../components/PoweredByMJ';
import CoalengineImage from '../components/CoalengineImage';
import { validateMobileNumber } from '../constants/validation';
import Feather from 'react-native-vector-icons/Feather';
import { PencilSquareIcon } from 'react-native-heroicons/outline';

const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;

//console.log('sh', screenHeight);

const PreSignIn = ({route, navigation}) => {
  const toast = useToast();
  const dispatch = useDispatch();
   
  const [check, setCheck] = useState(1);
  const [mob, setMob] = useState('');
  const [loginVia, setLoginVia] = useState(false);
  const [customerID, setCustomerID] = useState('');
  const [loading, setLoading] = useState(false);
  const [pin, setPin] = useState('');
  const [otp, setOTP] = useState('');
  const [submitBTN, setSubmitBTN] = useState(false);
  const [otpST, setOtpST] = useState(false);
  

  useEffect(() => {
    //console.log(screenWidth,' width: ',screenWidth * 0.62,screenHeight,' height: ',screenHeight * 0.30)
    //console.log('signup hit');
    AsyncStorage.getItem('my-key').then(token => {
      console.log('token signup', token);
      if (token != null) {
        navigation.replace('Dashboard');
      }
    });

 
  }, []);



  useFocusEffect(
    React.useCallback(() => {
      navigation.getParent('parentDrawer').setOptions({
        headerShown: false,
      });
      
    }, []),
  );

  const storeData = async (
    accessToken,
    refreshToken,
    conId,
    hierId,
    username,
    brandId,
    fullName,
    hierCode,
    hierDesc,
    id_extern01,
  ) => {
    try {
      await AsyncStorage.setItem('my-key', accessToken);
      await AsyncStorage.setItem('my-refresh-key', refreshToken);
      await AsyncStorage.setItem('contactId', conId + '');
      await AsyncStorage.setItem('hierId', hierId + '');
      await AsyncStorage.setItem('user-name', username + '');
      await AsyncStorage.setItem('brandId', brandId + '');
      await AsyncStorage.setItem('fullName', fullName + '');
      await AsyncStorage.setItem('hierCode', hierCode + '');
      await AsyncStorage.setItem('hierDesc', hierDesc + '');
      await AsyncStorage.setItem('id_extern01', id_extern01 + '');
    } catch (e) {
      // saving error
    }
  };

  function resetFields() {
    setCheck(1);
   setMob('');
   setCustomerID('');
   setOTP('');
   setPin('');
   
  }
  const otpHandler = () => {
    setCheck(p => p + 1);
    if(mob && customerID){
      setOtpST(true);
      
    }
  }
  const signInHandler = () => {
    setCheck(p => p + 1);

  }
  const signInHandler1 = () => {
    setCheck(p => p + 1);
    
        //  sign in via password
        if (1) {
          
          if (
            
            !password 
          ) {
            // intentionally kept blank
          } else {
            setLoading(true);
            const payload = {
              username:  mob,
             // password: password,
             // userType: selectedPersona.id,
            };
            // console.log("selectedPersona", selectedPersona)
            // console.log(payload)
            RegistrationService.login(payload)
              .then(res => {
                console.log('login res', JSON.stringify(res));

                if (res.success) {
                  setLoading(false);
                  dispatch(updateLoginStatus({isLoggedIn: true}))
                  console.log("b---------", res.response.userData.dcm_brands_id)
                  dispatch(
                    addHierarchicalId({
                      hierId: res.response.userData.dcm_hierarchies_id,
                    }),
                  );
                  
                  storeData(
                    res.response.access_token,
                    res.response.refresh_token,
                    res.response.userData.dcm_contacts_id,
                    res.response.userData.dcm_hierarchies_id,
                    res.response.userData.username,
                    res.response.userData.dcm_brands_id,
                    res.response.userData.full_name,
                    res.response.userData.hierCode,
                    res.response.userData.description,
                    res.response.userData.id_extern01,
                  );
                  console.log("reading toast")
                  toast.show('', {
                    data: {
                      isSuccess: true,
                      heading: 'Login Successful',
                      describe:
                        'You have successfully logged into RewardsConnect',
                    },
                  });

                  setTimeout(() => {
                    navigation.replace('Dashboard');
                  }, 1500);
                } else {
                  setLoading(false);
                  if (res.message == 'Bad request') {
                    toast.show('', {
                        data: {
                            isSuccess: false,
                            heading: 'Login failed!',
                            describe: res.response.message,
                          },
                      });
                  } else {
                    toast.show('', {
                        data: {
                            isSuccess: false,
                            heading: 'Login failed!',
                            describe: res.message,
                          },
                      });
                   
                  }
                }
              })
              .catch(err => {
                setLoading(false);
              });
          }
        } else {
          // sign in via otp login
        }
      
    
  };

  const gotoPin = (sreen) => {
    
    navigation.navigate(sreen);
  }
  
  const loginMethodChange=()=>{
    setCheck(1);
    setOtpST(false);
    setOTP('');
    setLoginVia(p => !p);
    resetFields();
  }
  const resendOTP = () => {
    
    if(mob && customerID){
      setOtpST(true);
      
    }
  }
  return (
    
      <FormBackground>
       
        <KeyboardAvoidingView
      style={{flex:1,}}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      
    >
<ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.mainBox}>
          
           <CoalengineImage logo={true} />
           

        <View style={styles.textDiv}>
          <Text style={styles.textWelcome} >{loginVia?'Login Using PIN':'Login To Your Account' }</Text>
          {!loginVia && otpST &&
          <View  style={styles.calendarIcon}>
          <Pressable onPress={()=>{setOtpST(false),setOTP('')}}>
                {/* <PencilSquareIcon size={24} color={"#666"} /> */}
                <Feather name="edit" size={21} color="#3C3C3C"  />
            </Pressable>
          </View>
          }
          </View>

          <View style={{width:'100%'}}>
              <InputField fieldName="Mobile No" editable={otpST?false:true} maxLength={10} keyboardType="numeric"  required={true} value={mob} setValue={setMob} check={check}  />
              <InputField fieldName="Customer ID"  editable={otpST?false:true} required={true} value={customerID} setValue={setCustomerID} check={check}  />
              {loginVia &&
              <InputField fieldName="Enter Pin"  editable={true} required={true} value={pin} setValue={setPin} check={check}  />
              }
              {!loginVia && otpST &&
              <InputField fieldName="OTP"  editable={true} required={true} value={otp} setValue={setOTP} check={check}  />
              }
              
                        
          </View> 
          {loginVia && 
          <View style={{paddingTop:6,flexDirection:'row',justifyContent:'space-between',paddingHorizontal:2,paddingBottom:4}}>
            <View><TouchableOpacity onPress={()=>gotoPin('CreatePin')}>
              <Text style={styles.textDontHave}>Don’t have a pin? <Text style={styles.textUnderLine}>Create Pin</Text></Text>
                </TouchableOpacity></View>
                <View><TouchableOpacity onPress={()=>gotoPin('ResetPin')}>
                <Text style={styles.textUnderLine}>Reset Pin</Text>
                </TouchableOpacity></View>
              </View>}
            <View style={{marginTop:1}}>
            {!loginVia && !otpST &&
              <ButtonNormal onPress={otpHandler} loading={loading}>
              Generate OTP
              </ButtonNormal>
}
{((loginVia && !otpST) || (!loginVia && otpST)) &&
              <ButtonNormal onPress={signInHandler} loading={loading}>
              Submit
              </ButtonNormal>
}
              <View style={{paddingTop:5}}>
              {!otpST &&
                <TouchableOpacity onPress={()=>loginMethodChange()}>
                <Text style={styles.textUnderLine}>Login Via {loginVia?'OTP':'Pin' }</Text>
                </TouchableOpacity>
            }
            {otpST &&
                <TouchableOpacity onPress={()=>resendOTP()}>
                <Text style={styles.textUnderLine}> Resend OTP</Text>
                </TouchableOpacity>
            }
              </View>
            </View>
             
        
          
        </View>
        
          
          </ScrollView>
          </KeyboardAvoidingView>
          
          <PoweredByMJ />
      </FormBackground>
      
    
  );
};

const styles = StyleSheet.create({
  calendarIcon:{position:'absolute',right:1,top:0,},
  textDontHave:{fontSize:theme.fontSizes.fontSize14,fontWeight:theme.fontsWeight.regular,fontFamily:theme.fonts.regular,
   lineHeight:17,color:'#282727',
  },
  textUnderLine:{fontSize:theme.fontSizes.fontSize14,fontWeight:theme.fontsWeight.medium,fontFamily:theme.fonts.medium,
    textAlign:'center',lineHeight:17,color:theme.colors.primary,textDecorationLine:'underline',
    textDecorationStyle:'solid',
  },
  textPowerby:{fontSize:theme.fontSizes.fontSize14,lineHeight:17,fontWeight:400,fontFamily:theme.fonts.regular,
    textAlign:'center',color:'#595858',marginBottom:screenHeight*0.01},
  textWelcome:{fontSize:theme.fontSizes.fontSize22,lineHeight:26,
    fontWeight:'700',fontFamily:theme.fonts.bold,
    //textAlign:'center',
    color:'#323030'},
  textDiv:{
    position:'relative',
    marginTop:screenHeight*0.02,
    marginBottom:screenHeight*0.015},
  mainBox:{
    //flex:1,
    marginBottom:40
    //minHeight: 807.27 * 0.8, 
    //height: screenHeight * 0.7,
    //marginTop:screenWidth * 0.025,
    //justifyContent:'space-between'
  },
   
  
  width100:{
    width:'100%'
  }

});

export default PreSignIn;
