export default eng = {
    'more_about_your_profile' : "More About Your Profile",
    'my_contractor' : "My Contractor",

    

}