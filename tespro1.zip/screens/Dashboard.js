import React, { useState, useEffect, useCallback } from 'react';
import {
  ScrollView,
  View,
  Text,
  StyleSheet,
  Image,
  Pressable,
  SafeAreaView,
  Dimensions,
  Modal,
  TouchableOpacity,
  Platform,
} from 'react-native';

import FormBackground from '../components/FormBackground';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import { ArrowRightIcon, CameraIcon, HomeIcon } from 'react-native-heroicons/outline';
import FooterTab from '../components/FooterTab';
import { Shadow } from 'react-native-shadow-2';



const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;

const Dashboard = ({ navigation }) => {
  const [currentTab, setCurrentTab] = useState('Performance');
  const [currentFilterTab, setcurrentFilterTab] = useState('MTD');
  const [modalSt, setModalSt] = useState(false);
  const [modalStd, setModalStd] = useState(false);
  return (
    <FormBackground>

      <View className="flex-1 w-full bg-white m-4  mt-[3px] shadow">
      {currentTab != 'Leaderboard' &&
        <View className="flex-row  p-3" >
          <View style={{ flex: 1 }}>
            <View>
              <Text className="text-[#191A32] text-[18px] font-semibold">Purushottam
                Chatterjee</Text>
              <Text className="text-[#14172B] text-[15px] font-semibold mt-[3px]"><MaterialCommunityIcons name="star-box" size={20} color="red" />4.6 <Text className="text-[12px] text-[#1D2436]">Out of 5</Text></Text>
            </View>
          </View>
          <View style={{ flex: 1 }}>
            <View className="mt-[-26px]">
              <Pressable
                className="rounded-full absolute p-1.5 bg-slate-400 "

                onPress={''}>
                
                {/* {profileImageLoader && <View style={{position: 'absolute', top: (screenWidth * 0.25/2)-11, left: (screenWidth * 0.25/2)-12 }}><ActivityIndicatorLoader/></View>} */}
              </Pressable>
              <Pressable
                className="p-1.5 absolute rounded-full"
                style={{ top: screenHeight * 0.085, left: screenWidth * 0.25, backgroundColor: 'red' }}
                onPress={''}>
                <CameraIcon size={18} fontWeight={700} color={'#fff'} />
              </Pressable>
            </View>
          </View>

          <View style={{ flex: 1 }}>
            <View className=" items-end">
              <Text className="text-[9px] text-[#6F7074] font-semibold">Incentive: <Text className="text-[#1D2436]">₹20,000/40,000</Text></Text>
              <View className="border border-[#000000] rounded items-center p-[4px] w-[65px] mt-[15px]"><Text className="text-[10px] text-[#000000] font-semibold">Very Good</Text></View>
            </View>

          </View>
        </View>
}

        <View className={currentTab!='Leaderboard'?'mt-[20px] flex-row ':' mt-[0px] flex-row '}>

          <View className="flex-1 relative items-center border-b-[1px] border-t-[1px] border-[#E5E5E5] pt-1 pb-1">
            <Pressable onPress={() => setCurrentTab('Performance')}>
              <Text
                className={`text-${currentTab == 'Performance' ? '[#FF1933]' : '[#000000]'
                  } text-[15px] font-semibold`}
              >
                Performance
              </Text>
            </Pressable>
            {currentTab == 'Performance' ? (
              <View className="relative left-[0] top-[5px] w-[100%]">
                <View className="border-b-[3px]  border-[#FF1933]"></View>
              </View>
            ) : null}
          </View>

          <View className="flex-1 relative items-center border-b-[1px] border-t-[1px] pt-1 pb-1 border-l-[1px] border-r-[1px] border-[#E5E5E5]">
            <Pressable onPress={() => setCurrentTab('Incentive')}>
              <Text
                className={`text-${currentTab == 'Incentive' ? '[#FF1933]' : '[#000000]'
                  } text-[15px] font-semibold`}
              >
                Incentive (₹)
              </Text>
            </Pressable>
            {currentTab == 'Incentive' ? (
              <View className="relative left-[0] top-[5px] w-[100%]">
                <View className="border-b-[3px]  border-[#FF1933]"></View>
              </View>
            ) : null}
          </View>
          <View className="flex-1 items-center relative border-b-[1px] border-t-[1px] border-[#E5E5E5] pt-1 pb-1">
            <Pressable onPress={() => setCurrentTab('Leaderboard')}>
              <Text
                className={`text-${currentTab == 'Leaderboard'
                    ? '[#FF1933]'
                    : '[#000000]'
                  } text-[15px] font-semibold`}
              >
                Leaderboard
              </Text>
            </Pressable>
            {currentTab == 'Leaderboard' ? (
              <View className="relative left-[0] top-[5px] w-[100%]">
                <View className="border-b-[2px] border-[#FF1933]"></View>
              </View>
            ) : null}
          </View>
        </View>

        {(currentTab == 'Performance' || currentTab == 'Leaderboard') &&
          <View className="flex-row mt-[5px] p-4">
            <View className={currentFilterTab == 'MTD' ? "flex-1 items-center border border-[#FF1933] rounded p-[5px] bg-[#FF1933]" : 'flex-1 items-center border border-[#E5E5E5] rounded p-[5px]'}>
              <Pressable onPress={() => setcurrentFilterTab('MTD')}>
                <View ><Text className={currentFilterTab == 'MTD' ? "text-[14px] text-[#fff] font-semibold" : "text-[14px] text-[#000000] font-semibold"}>MTD</Text></View>
              </Pressable>
            </View>
            <View className={currentFilterTab == 'QTD' ? "flex-1 items-center border border-[#FF1933] rounded p-[5px] mr-[20px] ml-[20px] bg-[#FF1933]" : 'flex-1 items-center border border-[#E5E5E5] rounded p-[5px] mr-[20px] ml-[20px]'}>
              <Pressable onPress={() => setcurrentFilterTab('QTD')}>
                <View ><Text className={currentFilterTab == 'QTD' ? "text-[14px] text-[#fff] font-semibold" : "text-[14px] text-[#000000] font-semibold"}>QTD</Text></View>
              </Pressable>
            </View>

            <View className={currentFilterTab == 'YTD' ? "flex-1 items-center border border-[#FF1933] rounded p-[5px] bg-[#FF1933]" : 'flex-1 items-center border border-[#E5E5E5] rounded p-[5px]'}>
              <Pressable onPress={() => setcurrentFilterTab('YTD')}>
                <View ><Text className={currentFilterTab == 'YTD' ? "text-[14px] text-[#fff] font-semibold" : "text-[14px] text-[#000000] font-semibold"}>YTD</Text></View>
              </Pressable>
            </View>

          </View>
        }
        {currentTab == 'Performance' &&
          <View className="flex-1 m-4 mt-2 p-2 border border-[#E5E5E5] rounded">
            <Text className="text-[15px] font-semibold text-[#000000] mb-2">Key Performance Indicator</Text>

            <View className="flex-row border border-[#E5E5E5] rounded  bg-[#F5F6FB] p-1">
              <View style={{ flex: .5 }}>
                <View className="relative">

                  
                  <View style={{ zIndex: 2 }} className="rounded-full h-[35px] w-[35px] bg-[#ffffff] justify-center items-center absolute top-[6px] left-[6px] right-0" >
                    <View className="rounded-full   ">
                      <Text className="text-[10px] font-semibold text-[#000000]">30%</Text>
                    </View>
                  </View>

                </View>
              </View>
              <View style={{ flex: 2 }}>
                <View className="pt-[5px] pl-[5px]">
                  <Text className="text-[12px] font-semibold text-[#000000]">NSV Performace </Text>
                  <Text className="text-[9px] font-semibold text-[#000000] pt-[4px]">Target: 1.3 (in Lakh) | Achievement: 0.26 (in Lakh)</Text>
                </View>
              </View>
              <View style={{ flex: .5 }}>
                <View className="items-end relative mt-[2px]">
                      <View className="absolute bottom-[-10px] right-[10px] items-center justify-center">
                    <Text className="text-[6px] font-semibold text-[#8FC53B]">1.1
                    </Text>
                    <Text className="text-[6px] font-semibold text-[#8FC53B]">
                      Points</Text>
                  </View>
                </View>



              </View>
            </View>

          </View>
        }

       

       



      </View>
      
      <FooterTab pageName="Home" />
    </FormBackground>
  );
};

const styles = StyleSheet.create({
  headingText: {
    fontFamily: 'Adani-Regular',
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#1E1E1E',
  },
  fontFamily: {
    fontFamily: 'Adani-Regular',
  },
  adaniBold: {
    fontFamily: 'Adani-Bold',
  },
  sec1Container: {
    paddingHorizontal: screenWidth * 0.03,
  },
  shadowProp: {
    shadowColor: '#171717',
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
  },

  shadowProp2: {
    shadowColor: 'rgba(0,0,0,0.12)',
    shadowOffset: {
      width: 2,
      height: 2,
    },
    shadowOpacity: 0.15,
    shadowRadius: 2,
    elevation: 3,
  },
  icon_box: {
    width: 30,
    height: 36,
    borderRadius: 2,
  },
  box: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 4,
    margin: 5,
    marginVertical: 8,
    width: 77,
    height: 77,
    backgroundColor: 'rgba(11, 116, 176, 0.028)',
    borderWidth: 1,
    borderColor: 'rgba(11, 116, 176, 0.15)',
    borderRadius: 5,
  },
  boxImage: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    // paddingVertical: 4,
    // paddingHorizontal: 4,
    margin: 5,
    marginVertical: 8,
    width: screenWidth * 0.33,
    height: screenWidth * 0.33,
    backgroundColor: 'rgba(255, 255, 255, 0.028)',
    borderWidth: 1,
    borderColor: 'rgba(11, 116, 176, 0.15)',
    borderRadius: 5
  },

  box_text: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingBottom: 3,
    fontFamily: 'Open Sans',
    fontStyle: 'normal',
    fontWeight: '400',
    fontSize: 13,
    lineHeight: 14,
    textAlign: 'center',
    color: 'rgba(0, 0, 0, 0.85)',

    alignItems: 'center',
  },

  image: {
    width: '100%',
    height: '100%',
  },

  horizontalScroll: {
    // // flex:1,
    // display: 'flex',
    // flexDirection: 'row',
    // width: 'auto'
  },
});

export default Dashboard;
