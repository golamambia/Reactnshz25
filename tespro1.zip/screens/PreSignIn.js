import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Pressable,
  Dimensions,
  Alert,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  BackHandler,
} from 'react-native';
 
import InputField from '../components/InputField';
import RegistrationService from '../services/registration';
import {useSelector} from 'react-redux';
import FormBackground from '../components/FormBackground';

import {useFocusEffect} from '@react-navigation/native';

import AsyncStorage from '@react-native-async-storage/async-storage';
import {useDispatch} from 'react-redux';
import {
  addBrandId,
  addContactId,
  addCreatedById,
  addHierarchicalId,
  addOrganizationId,
  updateLoginStatus,
  updateToken,
} from '../store/redux/currentUser';

import {useToast} from 'react-native-toast-notifications';
import ButtonNormal from '../components/ButtonNormal';
import ButtonWhite from '../components/ButtonWhite';
import theme from '../constants/theme';
import OptionsInputField from '../components/OptionsInputField';
import CustomDatePicker from '../components/CustomDatePicker';
import PoweredByMJ from '../components/PoweredByMJ';
import CoalengineImage from '../components/CoalengineImage';
import { SafeAreaView } from 'react-native-safe-area-context';

const screenHeight = Dimensions.get('screen').height;
const screenWidth = Dimensions.get('screen').width;
const screenHeightw = Dimensions.get('window').height;
console.log('sh', screenHeight);

const PreSignIn = ({route, navigation}) => {
  const toast = useToast();
  const dispatch = useDispatch();
   
  const [check, setCheck] = useState(1);

  const [selectedPersona, setSelectedPersona] = useState({id: '', title: ''});
  const [sap, setSap] = useState('');
  const [mob, setMob] = useState('');
  const [password, setPassword] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState({id: '', title: ''});
  const [allLanguages, setAllLanguages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [phase1Filled, setPhase1Filled] = useState(false);
  const [passCheck, setPassCheck] = useState(1);
  const [signInUsingOtp, setSignInUsingOtp] = useState(true);
  const [DateofJoin, setDateofJoin] = useState('');
  
  

  useEffect(() => {
    //console.log(screenWidth,' width: ',screenWidth * 0.62,screenHeight,' height: ',screenHeight * 0.30)
    //console.log('signup hit');
    AsyncStorage.getItem('my-key').then(token => {
      console.log('token signup', token);
      if (token != null) {
        navigation.replace('Dashboard');
      }
    });

 
  }, []);



  useFocusEffect(
    React.useCallback(() => {
      navigation.getParent('parentDrawer').setOptions({
        headerShown: false,
      });
      
    }, []),
  );

  const storeData = async (
    accessToken,
    refreshToken,
    conId,
    hierId,
    username,
    brandId,
    fullName,
    hierCode,
    hierDesc,
    id_extern01,
  ) => {
    try {
      await AsyncStorage.setItem('my-key', accessToken);
      await AsyncStorage.setItem('my-refresh-key', refreshToken);
      await AsyncStorage.setItem('contactId', conId + '');
      await AsyncStorage.setItem('hierId', hierId + '');
      await AsyncStorage.setItem('user-name', username + '');
      await AsyncStorage.setItem('brandId', brandId + '');
      await AsyncStorage.setItem('fullName', fullName + '');
      await AsyncStorage.setItem('hierCode', hierCode + '');
      await AsyncStorage.setItem('hierDesc', hierDesc + '');
      await AsyncStorage.setItem('id_extern01', id_extern01 + '');
    } catch (e) {
      // saving error
    }
  };

  function resetFields() {
    setCheck(1);
    setPassCheck(1);
   
  }
  const signInHandler = () => {
    setCheck(p => p + 1);

  }
  const signInHandler1 = () => {
    setCheck(p => p + 1);
    
        //  sign in via password
        if (!signInUsingOtp) {
          setPassCheck(p => p + 1);
          if (
            
            !password ||
            !selectedPersona.title
          ) {
            // intentionally kept blank
          } else {
            setLoading(true);
            const payload = {
              username:  mob,
              password: password,
              userType: selectedPersona.id,
            };
            // console.log("selectedPersona", selectedPersona)
            // console.log(payload)
            RegistrationService.login(payload)
              .then(res => {
                console.log('login res', JSON.stringify(res));

                if (res.success) {
                  setLoading(false);
                  dispatch(updateLoginStatus({isLoggedIn: true}))
                  console.log("b---------", res.response.userData.dcm_brands_id)
                  dispatch(
                    addHierarchicalId({
                      hierId: res.response.userData.dcm_hierarchies_id,
                    }),
                  );
                  
                  storeData(
                    res.response.access_token,
                    res.response.refresh_token,
                    res.response.userData.dcm_contacts_id,
                    res.response.userData.dcm_hierarchies_id,
                    res.response.userData.username,
                    res.response.userData.dcm_brands_id,
                    res.response.userData.full_name,
                    res.response.userData.hierCode,
                    res.response.userData.description,
                    res.response.userData.id_extern01,
                  );
                  console.log("reading toast")
                  toast.show('', {
                    data: {
                      isSuccess: true,
                      heading: 'Login Successful',
                      describe:
                        'You have successfully logged into RewardsConnect',
                    },
                  });

                  setTimeout(() => {
                    navigation.replace('Dashboard');
                  }, 1500);
                } else {
                  setLoading(false);
                  if (res.message == 'Bad request') {
                    toast.show('', {
                        data: {
                            isSuccess: false,
                            heading: 'Login failed!',
                            describe: res.response.message,
                          },
                      });
                  } else {
                    toast.show('', {
                        data: {
                            isSuccess: false,
                            heading: 'Login failed!',
                            describe: res.message,
                          },
                      });
                   
                  }
                }
              })
              .catch(err => {
                setLoading(false);
              });
          }
        } else {
          // sign in via otp login
        }
      
    
  };

  const gotoPin = () => {
    
    navigation.navigate('CreatePin');
  }
  const storList=[
{
  id:'1',
  title:'ABC'
},
{
  id:'2',
  title:'ABC2'
},
{
  id:'3',
  title:'ABC3'
}
  ]

  return (
    
      <FormBackground>
       
        <KeyboardAvoidingView
      style={{flex:1,}}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      
    >
<ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.mainBox}>
          
           <CoalengineImage logo={true} />
           

        <View style={styles.textDiv}>
          <Text style={styles.textWelcome} >Login To Your Account</Text>
          </View>

          <View style={{width:'100%'}}>
              <InputField fieldName="Mobile No"  keyboardType="numeric"  required={true} value={mob} setValue={setMob} check={check}  />
              <InputField fieldName="Customer ID"    editable={true} required={true} value={password} setValue={setPassword} check={check}  />
             
              {/* <OptionsInputField
                    data={storList}
                    fieldName="Store Name"
                    value={selectedLanguage}
                    setValue={setSelectedLanguage}
                    required={true}
                    check={check}
                    modalHeading="Select your Store"
                    modalIcon={''}
                  />    */}

                  {/* <CustomDatePicker
                //isDob={true}
                fieldText="Date of Joining"
                value={DateofJoin}
                setValue={setDateofJoin}
                required={true}
                check={check}
                placholder={'YYYY/MM/DD'}
              />     */}
                        
          </View>  

            <View style={{marginTop:1}}>
              <ButtonNormal onPress={signInHandler} loading={loading}>
              Generate OTP
              </ButtonNormal>
              <View style={{paddingTop:5}}>
                <TouchableOpacity onPress={()=>gotoPin()}>
                <Text style={styles.textUnderLine}>Login Via Pin</Text>
                </TouchableOpacity>
              </View>
            </View>
             
        
          
        </View>
        
          
          </ScrollView>
          </KeyboardAvoidingView>
          
          <PoweredByMJ />
      </FormBackground>
      
    
  );
};

const styles = StyleSheet.create({
  textUnderLine:{fontSize:14,fontWeight:theme.fontsWeight.medium,fontFamily:theme.fonts.medium,
    textAlign:'center',lineHeight:17,color:theme.colors.primary,textDecorationLine:'underline',
    textDecorationStyle:'solid',
  },
  textPowerby:{fontSize:theme.fontSizes.fontSize14,lineHeight:17,fontWeight:400,fontFamily:theme.fonts.regular,
    textAlign:'center',color:'#595858',marginBottom:screenHeight*0.01},
  textWelcome:{fontSize:theme.fontSizes.fontSize22,lineHeight:26,
    fontWeight:'700',fontFamily:theme.fonts.bold,
    //textAlign:'center',
    color:'#323030'},
  textDiv:{
    marginTop:screenHeight*0.02,
    marginBottom:screenHeight*0.015},
  mainBox:{
    //flex:1,
    marginBottom:40
    //minHeight: 807.27 * 0.8, 
    //height: screenHeight * 0.7,
    //marginTop:screenWidth * 0.025,
    //justifyContent:'space-between'
  },
   
  
  width100:{
    width:'100%'
  }

});

export default PreSignIn;
