import {
  Image,
  ImageBackground,
  Pressable,
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import React, {useState, useEffect, useCallback} from 'react'

import {
  HomeIcon,
  BellIcon,
  ExclamationCircleIcon,
  UserIcon,
  ArrowUpTrayIcon,
  PhotoIcon,
  GiftIcon,
  ShoppingCartIcon,
  DocumentTextIcon,
  ArrowDownTrayIcon,
  LockClosedIcon,
  QuestionMarkCircleIcon,
  LanguageIcon,
  DocumentMagnifyingGlassIcon,
  EnvelopeOpenIcon,
  PhoneArrowDownLeftIcon,
  StarIcon,
  ArrowRightOnRectangleIcon,
} from 'react-native-heroicons/outline';

import ButtonGradient from '../components/ButtonGradient';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { useFocusEffect } from '@react-navigation/native';
import OtherService from '../services/Other';
import Feather from 'react-native-vector-icons/Feather';
import { useDrawerStatus } from '@react-navigation/drawer';

const Sidebar = props => {
  const drawerStatus = useDrawerStatus();
 // console.log('drawerStatus',drawerStatus);
    const [conId, setConId] = useState("")
    const [hierId, setHierId] = useState("")
    const [hierName, setHiername] = useState("")
    
  //const navigation = useNavigation();

  const logoutHandler = navigation => {
    AsyncStorage.removeItem('my-key').then(res => {
      // dispatch(updateToken({token: ""}))
      console.log('my-key storage data', res);
      navigation.navigate('SignIn');
    });

    AsyncStorage.multiRemove([
      'contactId',
      'hierId',
      'user-name',
      'fullName',
      'brandId',
    ]).then(res => {
      console.log('Removed async storage data', res);
    });
  };

  useFocusEffect(
    React.useCallback(() => {
      
    }, [])
  );


  useEffect(() => {
    console.log('sidebar hit');
    
    AsyncStorage.getItem("contactId").then(conId=>{
      setConId(conId)
  })
  AsyncStorage.getItem("user-name").then(name=>{
      // console.log("NAMEEEE", name)
      //setUserName(name)
  })
  AsyncStorage.getItem("fullName").then(name=>{
      // console.log("NAMEEEE", name)
      //setFullName(name)
  })

 
 
 
},[drawerStatus]);

 
 
  return (
    <SafeAreaView style={styles.container}>
      {/* <ImageBackground
        style={{}}
        source={require('./../assets/Images/Rectangle-865.png')}> */}
        <View
          style={{
            width: '100%',
            height: 200,
            justifyContent: 'center',
            alignItems: 'center',
            borderBottomColor: '#f4f4f4',
            borderBottomWidth: 1,
            borderBottomEndRadius: 30,
            borderBottomStartRadius: 30,
            padding: 4,
            // backgroundColor:"#000"
          }}
          className="flex-row justify-between ">
           
              <View className="relative  ml-[-20px]">

             
            
                
                <View  style={{zIndex:2}} className="rounded-full h-[83px] w-[83px] bg-[#ffffff] justify-center items-center absolute top-[6px] left-[6px]" >
                  <View className="rounded-full h-[80px] w-[80px] ">
                    
                  </View>
                  </View>
                 
                   
                  <View className="rounded-full h-[100px] w-[100px] bg-[#ffffff]  justify-center items-center  top-[-2.5px] left-[-2.5px] right-0 absolute" style={{zIndex:1}} >
            </View>
                  </View>
          <View className="p-4 flex-col gap-4">
            <View>
              <Text className="text-white font-extrabold text-xl">
              Sen
              </Text>
              <Text className="text-white text-sm">  MOb: 9123456780</Text>
              <Text className="text-white text-sm">
                Available Points : 45465
              </Text>
            </View>
            <View className="flex-row">
            <Pressable  ><Text className="text-white text-sm">Edit Profile</Text></Pressable>
            <Pressable  >
               <Image source={require("./../assets/Images/edit-2.png")} className="ml-1 mt-[5px]" />
               </Pressable>
            </View>
          </View>
        </View>
      {/* </ImageBackground> */}

      <ScrollView>
        <View className="flex-1 pr-4 pl-4 mt-[8px] mb-[10px]">
          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              onPress={() => {
                props.navigation.navigate('Dashboard');
              }}>
              <View>
              <Feather name="home" size={20} color="gray" />
                
              </View>
              <View>
                <Text style={styles.boxText}> Home</Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              onPress={() => {
                props.navigation.navigate('AboutApp');
              }}>
              <View>
              <Feather name="alert-circle" size={20} color="gray" />
                 
              </View>
              <View>
                <Text style={styles.boxText}> About</Text>
              </View>
            </TouchableOpacity>
          </View>

          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              >
              <View>
              <Feather name="user" size={20} color="gray" />
              </View>
              <View>
                <Text style={styles.boxText}> My Profile</Text>
              </View>
            </TouchableOpacity>
          </View>
       

           
         
       
          
          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              onPress={() => {
                props.navigation.navigate("MyProfile");
              }}>
              <View>
              <Feather name="lock" size={20} color="gray" />
              </View>
              <View>
                <Text style={styles.boxText}>Change Password</Text>
              </View>
            </TouchableOpacity>
          </View>
          
          <View style={styles.box}>
            <TouchableOpacity
              className="flex-row"
              onPress={() => {
                props.navigation.navigate('TermsNCondition');
              }}>
              <View>
              <Feather name="file-text" size={20} color="gray" />
              </View>
              <View>
                <Text style={styles.boxText}>Terms & Condition</Text>
              </View>
            </TouchableOpacity>
          </View>
        
          
         
        
       
          
          <View style={styles.log_box}>
            <TouchableOpacity
              className="flex-row"
              onPress={() =>logoutHandler(props.navigation)}>
              <View>
              <Feather name="log-out" size={20} color="gray" />
              </View>
              <View>
                <Text style={styles.boxText}>Logout</Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* <View className="w-[92%] mx-4 my-6 shadow-lg shadow-slate-500 self-center">
            <ButtonGradient onPress={() => logoutHandler(props.navigation)}>
              Logout
            </ButtonGradient>
          </View> */}

        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
export default Sidebar;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  pageParents: {
    backgroundColor: '#6759FF',
    flexDirection: 'row',
    alignItems: 'center',
  },
  box: {
    borderBottomWidth: 1,
    borderBottomColor: '#CFCFCF',
    paddingTop: 10,
    paddingBottom: 10,
  },
  boxText: {
    fontSize: 13,
    color: '#000000',
    fontWeight: 'normal',
    textAlign: 'left',
    marginLeft: 12,
  },
  log_box: {
    //borderBottomWidth: 1,
    //borderBottomColor: '#CFCFCF',
    paddingTop: 10,
    paddingBottom: 10,
  },
});
