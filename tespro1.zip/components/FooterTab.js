import {
    Image,
    ImageBackground,
    Pressable,
    StyleSheet,
    Text,
    View,
    ScrollView,
    TouchableOpacity,
    SafeAreaView,
  } from 'react-native';
  import React, {useState, useEffect, useCallback} from 'react'
  
  import {
    HomeIcon,
    BellIcon,
    ExclamationCircleIcon,
    UserIcon,
    ArrowUpTrayIcon,
    PhotoIcon,
    GiftIcon,
    ShoppingCartIcon,
    DocumentTextIcon,
    ArrowDownTrayIcon,
    LockClosedIcon,
    QuestionMarkCircleIcon,
    LanguageIcon,
    DocumentMagnifyingGlassIcon,
    EnvelopeOpenIcon,
    PhoneArrowDownLeftIcon,
    StarIcon,
    ArrowRightOnRectangleIcon,
    MagnifyingGlassIcon,
  } from 'react-native-heroicons/outline';
  
  import ButtonGradient from '../components/ButtonGradient';
  import AsyncStorage from '@react-native-async-storage/async-storage';
  
  import { useFocusEffect, useNavigation } from '@react-navigation/native';
  import OtherService from '../services/Other';
  import Feather from 'react-native-vector-icons/Feather';
  import FontAwesome from 'react-native-vector-icons/FontAwesome';
  import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
  import {
    createBottomTabNavigator,
    BottomTabBar,
  } from '@react-navigation/bottom-tabs';


  
  const Tab = createBottomTabNavigator();
  const FooterTab =  ({ pageName = null }) => {
    const navigation = useNavigation();
      const [conId, setConId] = useState("");
       
      const [availablePoint, setAvailablePoint] = useState("");
    //const navigation = useNavigation();
    useEffect(() => {
      AsyncStorage.getItem("contactId").then(conId=>{
        setConId(conId)
    })
      console.log('Page Name:', pageName);
    }, [pageName]);
  

    const navigateToScreen = (screenName) => {
      navigation.navigate(screenName);
    };
    const logoutHandler = navigation => {
      AsyncStorage.removeItem('my-key').then(res => {
        // dispatch(updateToken({token: ""}))
        console.log('my-key storage data', res);
        navigation.navigate('SignIn');
      });
  
      AsyncStorage.multiRemove([
        'contactId',
        'hierId',
        'user-name',
        'fullName',
        'brandId',
      ]).then(res => {
        console.log('Removed async storage data', res);
      });
    };
    return (
 
      <View
              style={{
                
                borderTopLeftRadius: 11,
        borderTopRightRadius: 11,
        backgroundColor: '#FF1933',
        flexDirection: 'row',
        alignItems: 'center',
        position: 'absolute',
        bottom: -1,
        left: 0,
        right: 0,
        paddingVertical: 5,
        paddingHorizontal: 10,
   
    elevation: 50,
        backgroundColor: '#FF1933',
              }}
              
            >
           <View className="flex-row  pt-[6px] pb-[6px]" >
           <TouchableOpacity
       className="flex-1 relative items-center "
        onPress={() => navigateToScreen('Dashboard')}>
              
                    {
                        pageName=='Home1'?
                        (
                          <View>
                          <View className="absolute mt-[-22px] ml-[-20px]">
                          <View className="bg-white w-[70px] h-[70px] rounded-[35px]"></View>
                              </View> 
                              <HomeIcon size={28} color="#BD3861"  />
                              </View>
                         
                        ):(<MaterialCommunityIcons name="home" size={25} color="#FFFFFF"  />)
                      }
                      
                      <Text
                       className=" text-[#FFFFFF] text-[12px] font-ralebold"
                        style={styles.fontFamily}>
                        Home
                      </Text>
                      
                    

                    </TouchableOpacity>
                   
                    <TouchableOpacity
      className="flex-1 items-center relative"
      onPress={() => navigation.navigate("MyProfile")}>
                   {
                        pageName=='MyProfile1'?(<View>
                          <View className="absolute mt-[-22px] ml-[-20px]">
                              <View className="bg-white w-[70px] h-[70px] rounded-[35px]"></View>
                              </View> 
                              <UserIcon size={28} color="#BD3861"  />
                              </View> ):( <FontAwesome name="user" size={25} color="#FFFFFF"  />)
                      }
                   
                      <Text
                       className=" text-[#FFFFFF] text-[12px] font-ralebold"
                        style={styles.fontFamily}>
                       Profile
                      </Text>
                      
                   
                    </TouchableOpacity>
                    <TouchableOpacity
      className="flex-1 items-center relative"
      onPress={() => ''}>
                     
                    
                       
                      <View className="rounded-full relative  w-[65px] h-[65px] bg-white items-center mt-[-40px]">
                     
                    <View className="bottom-0 top-[0px] left-[0px] right-0 absolute items-center justify-center"
                    >
                      <View className="bg-primaryColor rounded-full w-[50px] h-[50px] items-center justify-center">
                      <MaterialCommunityIcons name="magnify" size={30} color="#FFFFFF"  />
                      </View>
                      
                      
                    </View>
                     

                  </View>
                    
                    </TouchableOpacity>
                    <TouchableOpacity
      className="flex-1 items-center relative"
      onPress={() => ''}>
                     
                    <Feather name="file-text" size={25} color="#FFFFFF"  />
                      <Text
                        className=" text-[#FFFFFF] text-[12px] font-ralebold"
                        style={styles.fontFamily}>
                       Terms
                      </Text>
                      
                    
                    </TouchableOpacity>
                    <TouchableOpacity
       className="flex-1 items-center relative"
        onPress={() => navigation.openDrawer()}>
                    
                    
                      {
                        pageName=='RewardsCatalogue1'?(<View>
                          <View className="absolute mt-[-22px] ml-[-20px]">
                              <View className="bg-white w-[70px] h-[70px] rounded-[35px]"></View>
                              </View> 
                              <GiftIcon size={28} color="#BD3861"  />
                              </View> ):(<Feather name="menu" size={25} color="#FFFFFF"  />)
                      }
                   
                      <Text
                        className=" text-[#FFFFFF] text-[12px] font-ralebold"
                        style={styles.fontFamily}>
                        Menu
                      </Text>
                      
                     
                    </TouchableOpacity>
          </View>
          </View>
    )     
    };
    export default FooterTab;
    
    const styles = StyleSheet.create({
      container: {
        flex: 1,
      },
      pageParents: {
        backgroundColor: '#6759FF',
        flexDirection: 'row',
        alignItems: 'center',
      },
      box: {
        borderBottomWidth: 1,
        borderBottomColor: '#CFCFCF',
        paddingTop: 10,
        paddingBottom: 10,
      },
      boxText: {
        fontSize: 13,
        color: '#000000',
        fontWeight: 'normal',
        textAlign: 'left',
        marginLeft: 12,
      },
      log_box: {
        //borderBottomWidth: 1,
        //borderBottomColor: '#CFCFCF',
        paddingTop: 10,
        paddingBottom: 10,
      },
    });
    